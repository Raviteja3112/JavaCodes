package Arrays;

public class ThreesumSub {
    public static void main(String[] args) {
        int[] z={1,2,4,5,6,7,16};

        int num=z[z.length-1]-z[0]-z[1];

        if(num==z[2] || num==z[3] ||num==z[4]||num==z[5]){
            System.out.println("YES");
            System.out.println(z[0]+" "+z[1]+" "+num);
        }
        else {
            System.out.println("NO");

        }

    }
}
