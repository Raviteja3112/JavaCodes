package Arrays;

public class PerfectNumber {
    public static void main(String[] args) {
        int count=0;
        int num=28;
        for(int i=1;i<=num;i++){
            if(num%i==0){
                count+=i;
            }
        }
        if(count==num){
            System.out.println("true");
        }
        else{
            System.out.println("false");
        }
    }
}
