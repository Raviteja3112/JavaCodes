package Arrays;

import java.util.Arrays;
import java.util.Scanner;

public class Cave {

    public static void main(String[] args) {
      int[] input1={12,2,36,10,217,36,5,36,15,10};
        System.out.println(Arrays.toString(input1));

      int[] result=new int[input1.length];
        for (int i = 0; i < input1.length; i++) {
            int count=1;
            for (int j = i+1; j < input1.length; j++) {
                if(input1[j]!=-1 && input1[i]==input1[j]){
                    input1[j]=-1;
                    count+=1;
                }
            }
            result[i]=count;
        }
        int max1=result[0];
        int max2=max1;
        int maxi=0,maxj=0;
        for (int i = 1; i < result.length; i++) {
            if(result[i]>max1){
                maxi=i;
                max1=result[i];
            }
            else{
                if(result[i]>max2){
                    maxj=i;
                    max2=result[i];
                }
            }
        }
        System.out.println(input1[maxi]+""+input1[maxj]);
    }
}
