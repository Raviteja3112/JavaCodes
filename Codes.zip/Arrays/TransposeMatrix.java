package Arrays;

public class TransposeMatrix {
    public static void main(String[] args) {
        int[][] transpose=new int[3][3];
        int[][] matrix=new int[3][3];

        for(int i=0;i<transpose.length;i++){
            for(int j=0;j<transpose[i].length;j++){
               matrix[j][i]=transpose[i][j];

            }
        }
    }
}
