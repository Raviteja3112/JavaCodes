package Arrays;

import java.util.ArrayList;
import java.util.Arrays;

public class RemoveDup {
    public static int[] remove(int[] array){
        ArrayList<Integer> list=new ArrayList<>();
        for (int i = 0; i < array.length; i++) {
            if(!list.contains(array[i])){
                list.add(array[i]);
            }
        }
        int[] result=new int[list.size()];
        for (int i = 0; i < list.size(); i++) {
            result[i]=list.get(i);
        }
        return result;
    }
    public static void main(String[] args) {
        int[] array={1,1,3,2,4,1,4,5};
        array=remove(array);
        System.out.println(Arrays.toString(array));
    }
}
