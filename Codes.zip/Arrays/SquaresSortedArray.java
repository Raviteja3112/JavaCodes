package Arrays;

import java.util.Arrays;

public class SquaresSortedArray {
    public static void main(String[] args) {
        int[] nums = {-4,-1,0,3,10};
        for(int i=0;i<nums.length;i++){
            nums[i]=nums[i]*nums[i];
        }
        int start=0,end=nums.length-1;
        int[] array=new int[nums.length];
        int k= array.length;
        while(start<=end){
            if(nums[start]>=nums[end]){
               array[--k]= nums[start];
               start++;
            }
            else{
                array[--k]=nums[end];
                end--;
            }

        }
        System.out.println(Arrays.toString(nums));
    }
}
