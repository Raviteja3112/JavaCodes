package Arrays;

import java.util.Arrays;

public class MaxinGenerated {
    public static int max(int[] array,int start,int end){
        if(start==end){
            return array[start];
        }
        int divide=start+(end-start)/2;
        int leftmax=max(array,start,divide);
        int rightmax= max(array,divide+1,end);
        return Math.max(leftmax,rightmax);
    }

    public static int getMaximumGenerated(int n) {
        int[] array=new int[n+1];
        array[0]=0;
        array[1]=1;
        if(n<2){
            return 1;
        }
        int k=2;
        int num=2;
        while(num<=n){
            int quo=num/2;
            if(num%2==0){
                array[k]=array[quo];
            }
            else{
                array[k]=array[quo]+array[quo+1];
            }
            num++;
            k+=1;
        }
        System.out.println(Arrays.toString(array));
        return max(array,0,n);
    }

    public static void main(String[] args) {
        System.out.println(getMaximumGenerated(1));
    }
}
