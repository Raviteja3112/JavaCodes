package Arrays;

public class StringConcat {
    public static String findstringfirst(String[] input2){
        String name="";
        for (int i = 0; i < input2.length; i++) {
            if(concat(input2[i])){
                name+=input2[i].toLowerCase();
            }
        }
        if(name.isEmpty()){
            name="no matches found";
        }
        return name;
    }
    public static  boolean concat(String name){
        name=name.toLowerCase();
        char first=name.charAt(0);
        char last=name.charAt(name.length()-1);

        if(first=='a' ||first=='e' || first=='i' || first=='o' || first=='u'){
            if (last=='a' ||last=='e' || last=='i' || last=='o' || last=='u'){
                return true;
            }
        }
        return false;
    }
    public static void main(String[] args) {
        String array[]={"bte","sirish","bpple"};


    }
}
