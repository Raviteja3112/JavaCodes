package Arrays;


import java.util.Arrays;
import java.util.Scanner;

public class SumPrime {

    public static void main(String[] args) {

        Scanner input=new Scanner(System.in);

        int testcases= input.nextInt();

        while(testcases-->0) {
            int size = input.nextInt();

            int[] array = new int[size];
            for (int i = 0; i < size; i++) {
                array[i] = input.nextInt();
            }

            Arrays.sort(array);
            int len = array.length;
            int index = (len % 2 == 0) ? (len / 2) - 1 : len / 2;

            int key = array[index];

            int bill = 0;
            for (int i = 0; i < array.length; i++) {
                bill += Math.abs(array[i] - key);
            }
            System.out.println(bill);
        }

    }
}
