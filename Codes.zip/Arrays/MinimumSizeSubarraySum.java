package Arrays;

public class MinimumSizeSubarraySum {
    public static void main(String[] args) {
        int[] nums = {2,3,1,2,4,3};
        int target=7;
        int count=Integer.MAX_VALUE;
        for(int i=0;i<nums.length;i++){
            int k=i;
            int check=0;
            int sum=0;
            while (sum < target) {
                if (k == nums.length - 1) {
                    break;
                }
                sum += nums[k++];
                check += 1;
            }
            if(count>check){
                count=check;
            }
        }
        System.out.println(count);
    }
}
