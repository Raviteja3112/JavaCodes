package Arrays;

import java.util.Scanner;

public class AlphaJump {
    public static void main(String[] args) {

        String name="aaabbcdbdt";

        int count=1;
        char ch=name.charAt(0);

        if(name.length()<1){
            System.out.println("0");
        }

        for (int i = 1; i < name.length()-1; i++) {
                if(ch<=name.charAt(i+1) && name.charAt(i)-ch==0 || name.charAt(i)-ch==1){
                    ch=name.charAt(i);
                    count+=1;
                }
        }
        System.out.println(count);
    }
}
