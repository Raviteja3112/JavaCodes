package Arrays;

public class MaxSubarraySum {
    public static int maxSubArray(int[] nums) {
        int max=nums[0];
        int sum=0;
        for(int i=0;i<nums.length;i++){
            sum+=nums[i];
            if(max<sum){
                max=sum;
            }
            if(sum<=0){
                sum=0;
            }
        }
        return max;
    }
    public static void main(String[] args) {
        int[] array={13,-3,-25,20,-3,-16,-23,18,20,-7,12,-5,-22,15,-4,7};
        System.out.println(maxSubArray(array));
    }
}
