package Arrays;

import java.util.Arrays;

public class Matrix90Rotaion {
    public static void rotate(int[][] mat){
        int[][] change=new int[mat.length][mat.length];
        for (int i = 0; i < mat.length; i++) {
            int k= mat.length-1;
            for (int j = 0; j < mat[i].length; j++,k--) {
                change[k][i]=mat[i][j];
            }
        }

        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                mat[i][j]=change[i][j];
            }
        }
    }

    public static void main(String[] args) {
        int[][] mat = {{0, 0, 0}, {0, 1, 0}, {1, 1, 1}};

        int[][] target = {{1, 1, 1}, {0, 1, 0}, {0, 0, 0}};

        int flag = 1,check;
        while (flag <= 4)
        {
            check=0;
            for (int i = 0; i < mat.length; i++) {
                for (int j = 0; j < mat[i].length; j++) {
                    if (mat[i][j] != target[i][j]) {
                        rotate(mat);
                        check=1;
                        break;
                    }
                }
            }
            if(check==0){
                break;
            }
            flag+=1;
    }

    }
}
