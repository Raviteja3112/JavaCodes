package Arrays;

import java.util.Arrays;

public class MinMaxDig {
    public static boolean checkStable(int a){
        int[] array=new int[10];
        if(a==0){
            return true;
        }
        while(a>0){
            int rem=a%10;
            array[rem]++;
            a/=10;
        }
        int check=0;
        int index=0;
        for (int i = 0; i < array.length; i++) {
                if(array[i]!=0){
                    check=array[i];
                    index=i;
                    break;
            }
        }
        for (int i = index; i < array.length ; i++) {
            if(array[i]!=0  && array[i]!=check){
                return false;
            }
        }
        return true;
    }

    public static int findPassword(int a,int b,int c,int d,int e){
        int[] array=new int[5];
        int k=0;
        if(checkStable(a)){
            array[k++]=a;
        }
        if(checkStable(b)){
            array[k++]=b;
        }
        if(checkStable(c)){
            array[k++]=c;
        }
        if(checkStable(d)){
            array[k++]=d;
        }
        if(checkStable(e)){
            array[k]=e;
        }
        int min=array[0];
        int max=array[0];
        for (int i = 1; i <=k; i++) {
            if(array[i]>max){
                max=array[i];
            }
            else{
                if(array[i]!=0 && array[i]<min ){
                    min=array[i];
                }
            }
        }
        return max-min;
    }
    public static void main(String[] args) {
        int a=12,b=1313,c=122,d=678,e=898;
        System.out.println(findPassword(a,b,c,d,e));
    }
}
