package Arrays;

public class Powerof2 {
    static int pow(int base,int num){
        if(num==1){
            return base;
        }
        else{
            int div=num/2;
            int left=pow(base,div);
            if((num&1)==0){
                return left*left;
            }
            return left*left*2;
        }
    }

    public static void main(String[] args) {
        for (int i = 1; i <=10; i++) {
            System.out.println(pow(2,i));
        }

    }
}
