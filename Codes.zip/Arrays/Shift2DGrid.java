package Arrays;

import java.util.ArrayList;

public class Shift2DGrid {
    public static void main(String[] args) {
        int[][] grid = {{1,2,3},{4,5,6},{7,8,9}};
        int k = 2;
        int m= grid.length,n= grid[0].length;

//        Element at grid[i][j] moves to grid[i][j + 1].
//                Element at grid[i][n - 1] moves to grid[i + 1][0].
//                Element at grid[m - 1][n - 1] moves to grid[0][0].

        ArrayList<Integer> list= new ArrayList<>();
        for (int  t= 0;  t<k ; t++) {
            for (int i = 0; i < m; i++) {
                for (int j = 0; j < n; j++) {
                    list.add(grid[i][j]);
                }
            }
            list.add(0,grid[m-1][n-1]);
            list.remove(list.size()-1);
            int index=0;
            for (int i = 0; i < m; i++) {
                for (int j = 0; j < n; j++) {
                    grid[i][j]=list.get(index++);
                }
            }
        }

        ArrayList<ArrayList<Integer>> list2= new ArrayList<>();
        k=0;
        for (int i = 0; i < m; i++) {
            list2.add(new ArrayList<>());
            for (int j = 0; j < n; j++) {
                list2.get(i).add(list.get(k++));
            }
        }
        for(ArrayList<Integer> nums:list2){
            System.out.println(nums);
        }
    }
}
