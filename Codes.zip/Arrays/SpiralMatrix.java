package Arrays;

import java.util.ArrayList;

public class SpiralMatrix {
    public static void main(String[] args) {
        int[][] matrix = {{4},{5},{12}};
        int top=0,bot= matrix.length-1,left=0,right=matrix[0].length-1;
        ArrayList<Integer> list=new ArrayList<>();
        while(top<=bot && left<=right){
            for(int i=left;i<=right;i++){
                list.add(matrix[top][i]);
            }
            top+=1;

            for(int i=top;i<=bot;i++){
                list.add(matrix[i][right]);
            }
            right-=1;

            if(top>bot || left>right){
                break;
            }

            for(int i=right;i>=left;i--){
                list.add(matrix[bot][i]);
            }
            bot-=1;

            for(int i=bot;i>=top;i--){
                list.add(matrix[i][left]);
            }
            left+=1;
        }

        System.out.println(list);

    }
}
