package Arrays;

import java.util.Arrays;

public class StringNumSort {
    public static void main(String[] args) {
        String num="3435335";

        int[] array = new int[num.length()];
        for (int i = 0; i < num.length(); i++) {
            array[i]=num.charAt(i)-'0';
        }
        Arrays.sort(array);

        num="";
        for (int i = array.length-1; i >=0; i--) {
            num+= String.valueOf(array[i]);
        }
        System.out.println(num);

    }
}
