package Arrays;

import java.util.ArrayList;
import java.util.List;

public class PascalTriangle {
    public static void main(String[] args) {
        List<List<Integer>> triangle=new ArrayList<>();
        int numRows=5;
        triangle.add(new ArrayList<>());
        triangle.get(0).add(1);

        for(int i=1;i<numRows;i++) {
            List<Integer> prev_row= triangle.get(i-1);
            List<Integer> cur_row=new ArrayList<>();
            cur_row.add(1);
            int start=0;
            for(int j=1;j< prev_row.size();j++){
                cur_row.add(prev_row.get(start)+prev_row.get(start+1));
                start+=1;
            }
            cur_row.add(1);
            triangle.add(new ArrayList<>());
            triangle.get(i).addAll(cur_row);

        }
        System.out.println(triangle);
    }
}
