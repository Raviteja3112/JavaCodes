package Arrays;

import java.util.Arrays;

public class RotateImage {
    public static void main(String[] args) {
        int[][] matrix = {{1,2,3},{4,5,6},{7,8,9}};
        int[][] array=new int[matrix.length][matrix.length];

        int row= 0,col= matrix.length-1;
        for (int i = 0; i < matrix.length ; i++) {
            for (int j = 0; j < matrix.length; j++) {
                array[row++][col]=matrix[i][j];
            }
            col--;
            row=0;
        }
        for (int i = 0; i < matrix.length ; i++) {
            for (int j = 0; j < matrix.length; j++) {
                matrix[i][j]=array[i][j];
            }
        }

        for(int[] nums:matrix){
            System.out.println(Arrays.toString(nums));
        }
    }
}
