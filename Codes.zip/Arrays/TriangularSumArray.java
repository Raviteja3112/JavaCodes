package Arrays;

public class TriangularSumArray {
    public static int triangularSum(int[] nums) {
        for(int i= nums.length-1;i>=0;i--){
            int k=0;
            for (int j =i; j >0; j--,k++) {
                int num=nums[k]+nums[k+1];
                if(num>9){
                    int rem=num%10;
                    nums[k]=rem;
                }
                else{
                    nums[k]=num;
                }
            }
        }
        return nums[0];
    }
    public static void main(String[] args) {
        int[] array={1,2,3,4,5};
        System.out.println(triangularSum(array));
    }
}
