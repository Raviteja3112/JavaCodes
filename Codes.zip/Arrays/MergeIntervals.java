package Arrays;

import java.util.Arrays;

public class MergeIntervals {
    public static void main(String[] args) {
        int[][] intervals = {{1,3},{2,6},{8,10},{15,18}};
        int[][] merge=new int[intervals.length][2];
        int[] array=new int[intervals.length*2];

        int index=0;
        for (int i = 0; i < intervals.length; i++) {
            for (int j = 0; j < 2; j++) {
                array[index++]=intervals[i][j];
            }
        }

        int row=0,col=0,start=0,end=0;
        for (int i = 1; i < array.length; i=end+1) {
            start=i;
            while(array[i]>array[i+1]){
                end=i+1;
            }
            merge[row][col++]=array[start-1];
            merge[row++][col]=array[end];
            col=0;
        }

    }
}
