package Arrays;

import java.util.Arrays;

public class MaximumPopulationYear {
    public static void add(int[] logs,int[] array){
        for(int i=logs[0];i< logs[1];i++){
            array[i%1950]+=1;
        }
        System.out.println(Arrays.toString(array));
    }

    public static void main(String[] args) {
        int[][] logs= {{1950,1961},{1960,1971},{1970,1981}};

        int[] array=new int[101];

        for(int i=0;i<logs.length;i++){
            add(logs[i],array);
        }

        int max=array[0],index=0;
        for(int i=1;i< array.length;i++){
            if(max<array[i]){
                max=array[i];
                index=i;
            }
        }
        System.out.println("index: "+index);
        System.out.println(1950+index);
    }
}
