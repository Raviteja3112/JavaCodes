package Arrays;

public class ValidSuduko {
    public static boolean checkRow(char[] nums){
        int[] checker=new int[9];
        for (int i = 0; i < nums.length; i++) {
            if(nums[i]=='.'){
                continue;
            }
            int digit=(int)nums[i]-48;
            checker[digit-1]+=1;
            if(checker[digit-1]>=2){
                return false;
            }
        }
        return true;
    }

    public static boolean checkCol(char[][] nums,int index){
        int[] checker=new int[9];
        for (int i = 0; i < nums.length; i++) {
            if(nums[i][index]=='.'){
                continue;
            }
            int digit=(int)nums[i][index]-48;
            checker[digit-1]+=1;
            if(checker[digit-1]>=2){
                return false;
            }
        }
        return true;
    }

    public static boolean check3x3(char[][] nums,int startr,int startc){
        int[] checker=new int[9];
        for (int i = startr; i < 3; i++) {
            for (int j = startc; j < 3; j++) {
                if(nums[i][j]=='.'){
                    continue;
                }
                else{
                    int digit=(int)nums[i][j]-48;
                    checker[digit-1]+=1;
                    if(checker[digit-1]>=2){
                        return false;
                    }
                }
            }
        }
        return true;
    }

    public static void main(String[] args) {
        char[][] board ={{'5','3','.','.','7','.','.','.','.'}
,{'6','.','.','1','9','5','.','.','.'}
,{'.','9','8','.','.','.','.','6','.'}
,{'8','.','.','.','6','.','.','.','3'}
,{'4','.','.','8','.','3','.','.','1'}
,{'7','.','.','.','2','.','.','.','6'}
,{'.','6','.','.','.','.','2','8','.'}
,{'.','.','.','4','1','9','.','.','5'}
,{'.','.','.','.','8','.','.','7','9'}};


        int flag=0,startr=0,startc=0;
        for (int i = 0; i < board.length; i++) {
            flag=0;
            if(!checkRow(board[i])){
                flag=1;
            }
            if(!checkCol(board,i)){
                flag=1;
            }
            if(!check3x3(board,startr,startc)){
                flag=1;
            }
            if(flag==1){
                break;
            }
            if(startc==board[0].length-1){
                startc=0;
                startr=startr+3;
            }
            else{
                startc=startc+3;
            }
        }

        if(flag==1){
            System.out.println(false);
        }
        else{
            System.out.println(true);
        }
    }
}
