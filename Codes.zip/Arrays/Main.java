package Arrays;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner in =new Scanner(System.in);
        int[] array={1,1,2,2,2,2,3,3,4,4};
        int find=4;

        int[] result=new int[100001];
        for (int i = 0; i < array.length; i++) {
            result[array[i]]+=1;
        }

        for (int i = 0; i < 100001; i++) {
            if(find==result[i]){
                System.out.println(array[i]);
                break;
            }
        }

    }
}
