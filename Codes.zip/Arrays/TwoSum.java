package Arrays;

import java.util.Arrays;

public class TwoSum {
    public static int linearSearch(int[] nums,int target ){
        for(int i=0;i<nums.length;i++){
            if(target==nums[i]){
                return i;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        int[] nums = {3,3};
        int target = 6;

        int max=nums[0];
        for(int i=1;i< nums.length;i++){
            if(max<nums[i])
                max=nums[i];
        }
        int[] array=new int[max+1];
        for(int i=0;i< nums.length;i++){
            array[nums[i]]=nums[i];
        }
        System.out.println(Arrays.toString(array));

        int start=0,end= array.length-1;
       while (start<=end){
           while(array[start]==0){
               start+=1;
           }
           while(array[end]==0){
               end-=1;
           }
           if(array[start]+array[end]==target){
               int index1=linearSearch(nums,array[start]);
               int index2=linearSearch(nums,array[end]);
               System.out.println(index1+" "+index2);
           }
           if(array[start]+array[end]>target)
               end--;
           else
               start++;
       }

       /*
        for(int i=0;i<nums.length;i++){
            for(int j=i+1;j<nums.length;j++){
                if(nums[i]+nums[j]==target){
                    System.out.println("yes");
                }
            }
        }

        */
    }
}
