package Arrays;

import java.util.Scanner;

public class PalindromeNext {
    public static void main(String[] args) {
        int num;
        Scanner input=new Scanner(System.in);
        num=input.nextInt();
        boolean flag=true;

        while(flag){
            boolean check=checkPalindrome(num);
            if(check==true){
                System.out.println(num);
                flag=false;
            }
            else{
                num+=1;
            }
        }
    }
    public static boolean checkPalindrome(int num){
        int temp=num;
        int rem,sum=0;
        while(num>0){
            rem=num%10;
            sum=sum*10+rem;
            num/=10;
        }
        if(temp==sum){
            return true;
        }
        return false;
    }

}
