package Arrays;

public class LuckyNumbersMatrix {
    public static int[] checkMin(int[][] array,int row){
        int min=array[row][0],index=0;
        for(int i=1;i< array[row].length;i++){
            if(min>array[row][i]){
                min=array[row][i];
                index=i;
            }
        }
;
        return new int[]{min,index};
    }

    public static int[] checkMax(int[][] array,int col){
        int max=array[0][col],index=0;
        for(int i=1;i< array[col].length;i++){
            if(max<array[i][col]){
                max=array[i][col];
                index=i;
            }
        }

        return new int[]{max,index};
    }

    public static void main(String[] args) {
        int[][] matrix = {{3,7,8},{9,11,13},{15,16,17}};
        for(int i=0;i< matrix.length;i++){
                int[] minIndex=checkMin(matrix,i);
                int[] maxIndex=checkMax(matrix,minIndex[1]);
                if(minIndex[0]==maxIndex[0]){
                    System.out.println(matrix[maxIndex[1]][minIndex[1]]);
                }
        }

    }
}
