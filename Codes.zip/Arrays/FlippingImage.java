package Arrays;

import java.util.Arrays;

public class FlippingImage {
    public static void main(String[] args) {
        int[][] image = {{1,1,0,0},{1,0,0,1},{0,1,1,1},{1,0,1,0}};
        int start,end;
        for(int i=0;i<image.length;i++){
            start=0;
            end=image[i].length-1;
            for (int j=0;j<image[i].length/2;j++,start+=1,end-=1){
                if(image[i][start]==0){
                    image[i][start]=1;
                }
                else{
                    image[i][start]=0;
                }
                if(image[i][end]==0){
                    image[i][end]=1;
                }
                else{
                    image[i][end]=0;
                }
                int temp=image[i][start];
                image[i][start]=image[i][end];
                image[i][end]=temp;
            }
        }


        for(int[] arr:image){
            System.out.println(Arrays.toString(arr));
        }
    }
}
