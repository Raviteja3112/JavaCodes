package Arrays;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Intersection {
    public static void main(String[] args) {
        int[] nums1 = {4,9,5}, nums2 = {9,4,9,8,4};
        int[] array=new int[Math.max(nums1.length,nums2.length)];
        int k=0;
        Arrays.sort(nums1);
        Arrays.sort(nums2);
        int a=0,b=0;
        while(a!=nums1.length && b!=nums2.length){
            if(nums1[a]==nums2[b]){
                array[k]=nums1[a];
                a++;
                b++;
                if(k!=0 && array[k]!=array[k-1]){
                    k+=1;
                }
            }
            else{

                if(nums1[a]>nums2[b]){
                    b++;
                }
                else{
                    a++;
                }
            }
        }
        int[] result=new int[k+1];
        for(int i=0;i<=k;i++){
            result[i]=array[i];
        }
        System.out.println(Arrays.toString(result));
    }
}
