package Arrays;

import java.util.Arrays;

public class CellswithOddValuesMatrix {
    public static void main(String[] args) {
        int m = 1, n = 1;
        int[][] indices = {{0,0},{0,0}};
        int[][] array=new int[m][n];


        for(int i=0;i<indices.length;i++){
            int index=indices[i][0];
            for(int l=0;l<n;l++){
                array[index][l]+=1;
            }

            index=indices[i][1];
            for(int l=0;l<m;l++){
                array[l][index]+=1;
            }
        }


        int count=0;
        for(int i=0;i< array.length;i++){
            for(int j=0;j<array[i].length;j++){
                if(array[i][j]%2!=0){
                    count+=1;
                }
            }
        }
        for(int[] arr:array){
            System.out.println(Arrays.toString(arr));
        }



    }
}
