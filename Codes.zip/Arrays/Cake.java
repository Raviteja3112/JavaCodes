package Arrays;

import java.util.Scanner;

public class Cake {
    public static void main (String[] args)
    {
        Scanner input=new Scanner(System.in);

        int k = input.nextInt();
        int a = input.nextInt();
        int b = input.nextInt();
        int C1 = Math.min(a,b);
        int C2 = Math.max(a,b);
        if(C2-C1==k/2) System.out.println("0");
        else if(C2-C1 < k/2) System.out.println(C2-C1-1);
        else System.out.println(k+C1-C2-1);

    }
}
