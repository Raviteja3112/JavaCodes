package Arrays;

import java.util.Arrays;

public class FirstMissingPositive {
    public static void main(String[] args) {
        int[] nums = {3,4,-1,1};

        int i=0;
        while(i< nums.length){
            int correctIndex=nums[i]-1;
            if(nums[i]>0 && correctIndex< nums.length && nums[i]!=nums[correctIndex]){
                int temp=nums[i];
                nums[i]=nums[correctIndex];
                nums[correctIndex]=temp;
            }
            else{
                i++;
            }
        }
        for(i=0;i<nums.length;i++){
            if(nums[i]!=i+1){
                System.out.println(i+1);
            }
        }
        System.out.println(Arrays.toString(nums));
    }
}
