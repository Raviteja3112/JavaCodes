package Arrays;

import java.util.Arrays;

public class MatrixMul {
    public static void main(String[] args) {
        int m=2,n=3,o=3,p=2;

        int[][] a={{1,2,3},{4,5,6}};
        int[][] b={{10,11},{20,21},{30,31}};
        int[][] c=new int[m][p];

        for (int row = 0; row < m; row++) {
            for (int col = 0; col < p; col++) {
                for (int i = 0; i <n; i++) {
                    c[row][col]+=a[row][i]*b[i][col];
                }
            }
        }
        for (int[] array:c) {
            System.out.println(Arrays.toString(array));
        }

    }
}
