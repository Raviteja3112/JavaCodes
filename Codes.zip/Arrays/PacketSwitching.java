package Arrays;

public class PacketSwitching {
    public static float packetsize(int packet,int header,int band,int count){
        int pac=packet/count;
        pac+=header;
        float tra=(float) pac/band;
        float singlepac=tra*3;
        return singlepac+(float) (count-1)*tra;
    }
    public static void main(String[] args) {
        int packet=1000;
        int header=100;
        int band=1000000;
        float total=0f;
        int count=1;
        boolean flag=true;

        float firstpac=packetsize(packet,header,band,count);
        float maxtran=firstpac;

        while(flag){
            float trans=packetsize(packet,header,band,++count);
            System.out.println("effiecncy: "+trans*1000+" count: "+count);
            if(maxtran>trans)
                maxtran=trans;
            else
                flag=false;
        }
        System.out.println(maxtran*1000+" "+count);
    }
}
