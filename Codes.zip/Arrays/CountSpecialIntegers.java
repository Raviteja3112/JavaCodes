package Arrays;

public class CountSpecialIntegers {
    public static int lengthCount(int num){
        if(num==1){
            return 9;
        }
        int sum;
        int total;
        int prevSum=0;
        for (int i = 1; i <=num; i++) {
            sum=9;
            total=sum;
            for (int j = 1; j <i ; j++) {
                total*=sum;
                sum--;
            }
            prevSum+=total;
        }
        return prevSum;
    }
    public static boolean distinct(int num){
        int[] array=new int[10];
        int temp=num;
        while(temp>0){
            int rem=temp%10;
            if(array[rem]==1){
                return false;
            }
            array[rem]+=1;
            temp/=10;
        }
        return true;
    }
    public static void main(String[] args) {
        int num=135;
        int length=(int)Math.log10(num)+1;
        int total=0;
        total=lengthCount(length-1);

        for(int i=(int)Math.pow(10,length-1);i<=num;i++){
            if(distinct(i)){
                total+=1;
            }
        }
        System.out.println(total);
        System.out.println(lengthCount(4));
    }
}
