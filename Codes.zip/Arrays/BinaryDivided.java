package Arrays;

import java.util.Arrays;

public class BinaryDivided {
    public static void main(String[] args) {
        /*
        String input1="1011110111";

        String[] input1=input1.split("0");
        String result="";
        for (int i = 0; i < input1.length; i++) {
            result+=(char)(input1[i].length()+64);
        }
        System.out.println(result);
         */
        int[] input1 = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
        int sum = 0;
        for (int num = 2; num <= input1.length; num++) {
            boolean isPrime = true;
            for (int i = 2; i <= num / 2; i++) {
                if (num % i == 0) {
                    isPrime = false;
                    break;
                }
            }
            if (isPrime == true) {
                sum += input1[num];
            }

        }
        System.out.println(sum);
    }
}