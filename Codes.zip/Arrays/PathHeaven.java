package Arrays;

public class PathHeaven {
    public static void main(String[] args) {
        int n=5;


        int count=0;
        if(n==1){
            System.out.println("1");
        }
        while(n>1){
            if(n%3==0){
                n/=3;
            }
            else if (n%2==0) {
                n/=2;
            }
            else{
                n-=1;
            }
            count+=1;
        }


        System.out.println(count);
    }
}
