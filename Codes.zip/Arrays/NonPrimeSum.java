package Arrays;

public class NonPrimeSum {
    public static boolean isPrime(int num){
        for (int i = 2; i <= (int)Math.sqrt(num); ++i) {
            if (num % i == 0) {
                return true;
            }
        }
       return false;
    }

    public static void main(String[] args) {
        int[] array={10,20,30,40,50,60,70,80,90,100};

        int sum=array[0]+array[1];
        for (int i = 2; i < array.length ; i++) {
            if(isPrime(i)){
                sum+=array[i];
            }
        }
        System.out.println(sum);
    }
}
