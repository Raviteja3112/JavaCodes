package Arrays;

import java.util.Arrays;

public class ASUBB {
    public static void onlyA(String[] arrayA,String[] intersec){
        int i=0,j=0;
        System.out.println(Arrays.toString(arrayA));
        System.out.println(Arrays.toString(intersec));
        while(arrayA.length>i){
            if(arrayA[i].equals(intersec[j])){
                i++;
                j++;
            }
            else{
                if(arrayA[i].compareTo(intersec[j])<0){
                    System.out.print(arrayA[i]+" ");
                    i++;
                }
                else{
                    j++;
                }
            }
        }
        System.out.println("were deleted today");
    }

    public static void intersection(String [] arrayA,String[] arrayB){
        String[] intersec=new String[arrayA.length];
        int i=0,j=0,k=0;
        while(arrayA.length>i){
            if(arrayA[i].equals(arrayB[j])){
                intersec[k++]=arrayA[i];
                i++;
                j++;
            }
            else{
                if(arrayA[i].compareTo(arrayB[j])<0){
                    i++;
                }
                else{
                    j++;
                }
            }
        }
        onlyA(arrayA,intersec);
    }

    public static void main(String[] args) {
        String[] arrayA={"a","b","c","d","e","f","fa","g","h","z"};
        String[] arrayB={"a","b","c","d","e","g","ga","gb","hj","z"};
        intersection(arrayA,arrayB);

    }
}
