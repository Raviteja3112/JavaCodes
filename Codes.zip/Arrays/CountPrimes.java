package Arrays;

import java.util.Arrays;

public class CountPrimes {
    public static void main(String[] args) {
        int n=10;
        int[] primes=new int[n-2];
        for (int i = 2; i <n; i++) {
            for (int j = 2; j <n; j++) {
                if(i!=j && j%i==0){
                    primes[j-2]=1;
                }
            }
        }
        System.out.println(Arrays.toString(primes));
        int count=0;
        for (int i = 0; i < primes.length; i++) {
            if(primes[i]==0){
                count+=1;
            }
        }
    }
}
