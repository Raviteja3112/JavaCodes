package Arrays;

public class MatrixDiagonalSum {
    public static void main(String[] args) {
        int[][] array={{1,2,3},
        {4,5,6},
        {7,8,9}};

        int sum=0;
        for(int i=0;i<array.length;i++){
            sum+=array[i][i];
        }

        for(int i=array.length-1;i>=0;i--){
            sum+=array[i][i];
        }

        if(array.length%2!=0){
            sum=sum-array[array.length/2][array.length/2];
        }
        System.out.println(sum);
    }
}
