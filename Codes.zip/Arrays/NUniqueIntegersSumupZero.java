package Arrays;

import java.util.Arrays;

public class NUniqueIntegersSumupZero {
    public static void main(String[] args) {
        int n=6;
        int[] array=new int[n];

        int k=0;
        if(n%2!=0){
            int last=n-1;
            array[0]=0;
            for(int i=1;i<=n/2;i++,k+=1,last--){
                array[i]=i;
                array[last]=-i;
            }
        }
        else{
            int last=n-1;
            int start=0;
            for(int i=1;i<=n/2;i++,last-=1){
                  array[start++]=i;
                    array[last]=-i;
            }
        }
        System.out.println(Arrays.toString(array));
    }
}
