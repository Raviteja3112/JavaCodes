package Arrays;

public class FindMiddleIndexArray {
    public static int sum(int[] nums,int start,int end){
        int sum=0;
        for(int i=start;i< end;i++){
            sum+=nums[i];
        }
        return sum;
    }

    public static void main(String[] args) {
        int[] nums = {2,3,-1,8,4};
        for(int i=0;i< nums.length;i++){
            if(sum(nums,0,i)==sum(nums,i+1, nums.length)){
                System.out.println(i);
                break;
            }
        }
    }
}
