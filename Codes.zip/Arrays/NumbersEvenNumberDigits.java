package Arrays;

public class NumbersEvenNumberDigits {
    public static void main(String[] args) {
        int[] nums = {12,345,2,6,7896};

        int sum=0;
        for(int i=0;i< nums.length;i++){
            sum+=digits(nums[i]);
        }
    }

    public static int digits(int num){
        int count=0;
        while(num>0){
            count+=1;
            num/=10;
        }
        if(count%2==0){
            return 1;
        }
        return 0;
    }

}
