package Arrays;

import java.util.Arrays;

public class ReshapeMatrix {
    public static void main(String[] args) {
        int[][] mat = {{1,2},{3,4}};
        int r = 1, c = 4;

        int[][] reshape=new int[r][c];
        int row=0,col=0;
        for(int i=0;i< mat.length;i++){
            for(int j=0;j<mat[i].length;j++){
                reshape[row][col]=mat[i][j];
                col++;
                if(col==c){
                    row++;
                    col=0;
                }
            }
        }

        for (int[] num:reshape) {
            System.out.println(Arrays.toString(num));
        }
    }
}
