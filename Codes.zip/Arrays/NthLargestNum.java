package Arrays;

import java.util.Scanner;

public class NthLargestNum {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);

        int size=input.nextInt();
        int[] array=new int[size];
        for (int i = 0; i < size; i++) {
            array[i]= input.nextInt();
        }
        int k=input.nextInt();

        for (int i = 0; i < k; i++) {
            for (int j = 0; j < array.length-i-1; j++) {
                if(array[j]>array[j+1]){
                    int temp=array[j];
                    array[j]=array[j+1];
                    array[j+1]=temp;
                }
            }
        }
        System.out.println(array[array.length-k]);
    }
}
