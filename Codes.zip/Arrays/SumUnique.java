package Arrays;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Stack;

public class SumUnique {

    public static void main(String[] args) {
        int[] head = {1,2,3,-3,1};
        Stack<Integer> stack=new Stack<>();

        for (int i = 0; i < head.length; i++) {
            if(stack.isEmpty()){
                stack.push(head[i]);
            }
            else{
                if(stack.peek()+head[i]==0){
                    stack.pop();
                }
                else{
                    stack.push(head[i]);
                }
            }
        }
        System.out.println(stack);
        ArrayList<Integer> list=new ArrayList<>();
        while (!stack.isEmpty()) {
            list.add(0,stack.pop());
        }
        System.out.println(list);





    }
}
