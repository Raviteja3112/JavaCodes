package Arrays;

public class LargeKey {
    public static void main(String[] args) {
        int a=3521,b=2452,c=1352;
        int num=4,key=0;
        while(num>0){
            int rem1=a%10;
            int rem2=b%10;
            int rem3=c%10;
            int large=Math.max(Math.max(rem1,rem2),rem3);
            int small=Math.min(Math.min(rem1,rem2),rem3);
             key=key*10+(large-small);
            num-=1;
            a/=10;
            b/=10;
            c/=10;
        }
        int sum=0;
        while(key>0){
            int rem=key%10;
            sum=sum*10+rem;
            key/=10;
        }
        System.out.println(sum);
    }
}
