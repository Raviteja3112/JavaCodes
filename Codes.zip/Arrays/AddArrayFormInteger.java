package Arrays;

import java.util.ArrayList;
import java.util.Arrays;

public class AddArrayFormInteger {
    public static void main(String[] args) {
        int[] num = {9,9,9,9,9,9,9,9,9,9};
        int k = 1;

        int a;

        long sum=0;

        for(int i=0;i<num.length;i++){
            sum=sum*10+num[i];
        }
        sum+=k;

        ArrayList<Integer> list=new ArrayList<>();

        System.out.println(sum%10);


      while(sum>0){
          long digit=sum%10;
          System.out.println(digit);
          list.add(0,(int)digit);
          sum/=10;
      }

        System.out.println(list);
    }
}
