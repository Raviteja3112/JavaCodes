package Arrays;

import java.util.ArrayList;
import java.util.Arrays;

public class CountItemMatchingRule {
    public static int countMatches(ArrayList<ArrayList<String>> items, String ruleKey, String ruleValue) {
        int index=-1;
        switch (ruleKey){
            case "type"->index=0;
            case "color"->index=1;
            case "name"->index=2;
        }

        int count=0;
        for (int i=0;i< items.size();i++){
                if (items.get(i).get(index).equals(ruleValue)) {
                    System.out.println(items.get(i).get(index));
                }
        }
        return count;
    }
    public static void main(String[] args) {
        ArrayList<ArrayList<String>> list=new ArrayList<ArrayList<String>>();
        for(int i=0;i<3;i++){
            list.add(new ArrayList<String>());
        }
        String[][] array={{"phone","blue","pixel"},
                {"computer","silver","lenovo"},
                {"phone","gold","iphone"}};

        String ruleKey = "type";
        String ruleValue = "phone";

        for(int i=0;i<3;i++){
            for(int j=0;j<3;j++){
                list.get(i).add(array[i][j]);
            }
        }

        countMatches(list,ruleKey,ruleValue);

    }
}
