package Arrays;

import java.util.Arrays;

public class ProductArrayExceptSelf {
    public static void main(String[] args) {
        int[] nums = {0, 4,0};
        int count=0;

        for(int i=0;i< nums.length;i++){
            if(nums[i]==0){
                count+=1;
            }
        }

        if(count>1){
            for(int i=0;i< nums.length;i++){
                nums[i]=0;
            }
        }
        else{
            int sum=1,zero=0;
            for(int i=0;i< nums.length;i++){
                if(nums[i]!=0){
                    sum*=nums[i];
                }
                else{
                    zero=1;
                }
            }
            for(int i=0;i<nums.length;i++){
                if(nums[i]==0){
                    nums[i]=sum;
                }
                else if(zero==1){
                    nums[i]=0;
                }
                else{
                    nums[i]=sum/nums[i];
                }
            }
        }


    }
}
