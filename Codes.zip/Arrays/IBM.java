package Arrays;

import java.util.ArrayList;

public class IBM {
    public static void totalPay(ArrayList<Integer> phases,int lastAmount){
        if(phases.get(0)<=1){
            return;
        }

        int per= phases.get(phases.size()-1);
        per*=10;
        int total=(lastAmount*100)/per;
        System.out.println(total);

    }
    public static void main(String[] args) {
        //intial pay, 2:3:5 ratio
        ArrayList<Integer> phases=new ArrayList<>();
        phases.add(3);
        phases.add(2);
        phases.add(3);
        phases.add(5);
        int amount=350000;
        totalPay(phases,amount);
    }
}
