package Arrays;

public class First2ndDigit {
    public static void main(String[] args) {
        int num=123456789;
        int k=3;

        int power=(int)Math.pow(10,k);
        while(num>power){
            num/=10;
        }
        System.out.println(num%10);

    }
}
