package Arrays;

import java.util.ArrayList;
import java.util.Scanner;

public class Lexographically {
    public static void main(String[] args) {

        Scanner input=new Scanner(System.in);
        String sen=input.next();
        int num=input.nextInt();
        String[] words=sen.split(" ");

        ArrayList<String > repeated=new ArrayList<>();

        for (int i = 0; i < words.length; i++) {
            int count=0;
            String word=words[i];
            for (int j = 0; j < words.length; j++) {
                if(word.equals(words[j])){
                    count+=1;
                }
            }
            if(count>=num){
                if(!repeated.contains(word))
                     repeated.add(word);
            }
        }
        System.out.println(repeated);
    }
}
