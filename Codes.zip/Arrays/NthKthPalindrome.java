package Arrays;

public class NthKthPalindrome {
    public static int checkPalindrome(int num){
        int temp=num;
        int sum=0;
        while(num>0){
            int rem=num%10;
            sum=sum*10+rem;
            num/=10;
        }
        if(temp==sum){
            return temp;
        }
        return -1;
    }
    public static void main(String[] args) {
        int n=4,k=5;
        int startNum= (int) Math.pow(10,k-1);
        int count=0,check=0;
        while(count<n){
            check=checkPalindrome(startNum++);
            if(check>0){
                count+=1;
            }
        }
        System.out.println(check);
    }
}
