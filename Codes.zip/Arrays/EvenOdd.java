package Arrays;

public class EvenOdd {
    public static int Even(int a){
        return (a/1000) + (a/10)%10;
    }
    public static int Odd(int a){
        return (a/100)%10 + (a%10);
    }
    public static int findPin(int a,int b,int c,int d){
        int evensum=Even(a)+Even(b)+Even(c);
        int oddsum=Odd(a)+Odd(b)+Odd(c);
        if(d%2==0){
            return evensum-oddsum;
        }
        return oddsum-evensum;
    }
    public static void main(String[] args) {
        int a=3521,b=2452,c=1352,d=37;
        System.out.println(findPin(a,b,c,d));
    }
}
