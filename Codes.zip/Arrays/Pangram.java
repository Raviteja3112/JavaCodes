package Arrays;

public class Pangram {
    public static void main(String[] args) {
        String name="anmt";

        int[] aplha=new int[26];

        for(int i=0;i<name.length();i++){
            aplha[(int)name.charAt(i)-97]=1;
        }

        for(int num:aplha){
            if(num==0){
                System.out.println("not pangram");
            }
            else{
                System.out.println("pan");
            }
        }
    }
}
