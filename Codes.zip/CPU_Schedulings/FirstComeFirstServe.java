package CPU_Schedulings;

import java.util.ArrayList;

public class FirstComeFirstServe {

    public static void main(String[] args) {
        int[] processId={1,2,3,4,5,6};
        int[] arrivalTime={0,1,2,3,4,5};
        int[] burstTime={5,1,2,4,5,3};
        int[] completionTime=new int[processId.length];
        int[] turnAroundTime=new int[processId.length];
        int[] waitingTime=new int[processId.length];
        ArrayList<Integer> list=new ArrayList<>();
        int ct=0;
        if(arrivalTime[0]!=0){
            ct=arrivalTime[0];
        }

        System.out.println("Process  "+"Arrival  "+"Burst  "+"Completion  "+"TAT  "+"Waiting");
        for(int i=0;i< processId.length;i++){
            ct+=burstTime[i];
            completionTime[i]=ct;
            turnAroundTime[i]=completionTime[i]-arrivalTime[i];
            waitingTime[i]= turnAroundTime[i]-burstTime[i];
            list.add(processId[i]);
            System.out.print(processId[i]+"            "+ arrivalTime[i]+"        "+burstTime[i]+"       ");
            System.out.println(completionTime[i]+"        "+turnAroundTime[i]+"      "+waitingTime[i]);
        }

    }
}
