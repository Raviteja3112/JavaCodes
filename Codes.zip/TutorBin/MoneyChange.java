package TutorBin;

import java.util.Scanner;

public class MoneyChange {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);

        int money=in.nextInt();

        //quarters (25), dimes (10), nickels (5), and cents (1)
        if(money>0 && money<=100){
            int quarters=(money/25);
            money-=(quarters*25);
            int dimes=(money/10);
            money-=(dimes*10);
            int nickels=(money/5);
            money-=(nickels*5);
            int cents=money;

            if(quarters!=0){
                System.out.print(quarters+" quaters ");
            }
            if(dimes!=0){
                System.out.print(dimes+" dimes ");
            }
            if(nickels!=0){
                System.out.print(nickels+" nickels ");
            }
            if(cents!=0){
                System.out.print(cents+" cents");
            }
        }


    }
}
