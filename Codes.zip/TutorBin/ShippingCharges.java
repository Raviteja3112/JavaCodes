package TutorBin;

import java.util.Scanner;

public class ShippingCharges {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.println("Enter Weight in KG : ");
        float weight= in.nextFloat();
        System.out.println("Enter Distance in KM : ");
        int distance=in.nextInt();

        int sub=distance/200;
        int ratedShipped=sub;

        if((distance/200.0)-sub!=0) {
            ratedShipped = sub + 1;
        }

        float total;
        if(weight>10){
            total=ratedShipped*5;
        }
        else if (weight>6 && weight<=10){
            total=(float)(ratedShipped*3.75);
        }
        else if (weight>2 && weight<=6) {
            total=(float)(ratedShipped*2.2);
        }
        else{
            total=(float)(ratedShipped*1.1);
        }

        System.out.println("The charge will be : "+ total);
    }
}
