package TutorBin;

import java.util.Scanner;

public class IsVowel {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);

        System.out.println("Enter CHAR: ");
        char isVowel=in.next().toLowerCase().charAt(0);

        switch(isVowel){
            case 'a':
                System.out.println(isVowel+" is Vowel");
                break;
            case 'e':
                System.out.println(isVowel+" is Vowel");
                break;
            case 'i':
                System.out.println(isVowel+" is Vowel");
                break;
            case 'o':
                System.out.println(isVowel+" is Vowel");
                break;
            case 'u':
                System.out.println(isVowel+" is Vowel");
                break;
            default:
                System.out.println(isVowel+" is Not Vowel");
                break;
        }

    }
}
