package TutorBin;

import java.util.Scanner;

public class RunningRace {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);

        String[] names=new String[3];
        float[] time=new float[3];

        for (int i =0; i <3; i++) {
            System.out.println("Enter name"+(i+1)+" :");
            names[i]=in.next();

            System.out.println("Enter time "+(i+1)+" :");
            time[i]=in.nextFloat();
        }
        System.out.println("   Runner Name     Completion Time");

        for (int i = 0; i < 3; i++) {
            for (int j = i+1; j < 3; j++) {
                if(time[i]<time[j]){
                    float temp=time[i];
                    time[i]=time[j];
                    time[j]=temp;

                    String name=names[i];
                    names[i]=names[j];
                    names[j]=name;
                }
            }
        }

        for (int i = 0; i <3; i++) {
            System.out.println((i+1) + " "+ names[i] + " "+ time[i]);
        }

    }
}
