package TutorBin;
import java.util.List;
import java.util.Scanner;


public class BinarySearch {
    public <T extends Comparable< ? super T>> int search(List<T> list, T target) {
        int start = 0;
        int end = list.size() - 1;
        while (start <= end) {
            int mid = start + (end - start) / 2;
            int compare = target.compareTo(list.get(mid));
            if (compare == 0) {
                return mid;
            } else if (compare < 0) {
                end = mid - 1;
            } else {
                start = mid + 1;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        List<Integer> numbers = List.of(12, 23, 36, 49, 55, 62, 77, 84, 96);
        BinarySearch s=new BinarySearch();
        Scanner in =new Scanner(System.in);
        System.out.println("Target value: ");
        int target=in.nextInt();
        int index = s.search(numbers, target);
        if (index == -1) {
            System.out.println("Element not found");
        } else {
            System.out.println("Element found at index " + index);
        }
    }

}
