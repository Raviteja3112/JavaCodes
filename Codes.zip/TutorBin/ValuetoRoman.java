package TutorBin;

import java.util.Scanner;

public class ValuetoRoman {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.println("Input: ");
        int num=in.nextInt();
        System.out.println("Output: ");

        if(num>=1 && num<=20){
            while(num>0){
                if(num>=10){
                    System.out.print("X");
                    num-=10;
                }
                else if(num==9){
                    System.out.print("IX");
                    num-=9;
                }
                else if(num>=5){
                    System.out.print("V");
                    num-=5;
                }
                else if(num==4){
                    System.out.println("IV");
                    num-=4;
                }
                else{
                    if(num>=1){
                        System.out.print("I");
                        num-=1;
                    }
                }
            }

        }
        else{
            System.out.println("Number exceeds the range.");
        }

    }
}
