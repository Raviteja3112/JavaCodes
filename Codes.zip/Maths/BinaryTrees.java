package Maths;
import java.util.*;
// Java implementation to find leaf count of a given Binary tree

/* Class containing left and right child of current
node and key value*/
class Node
{
    int data;
    Node left, right;

    public Node(int item)
    {
        data = item;
        left = right = null;
    }
}

public class BinaryTrees
{
    int[] array=new int[3];
    //Root of the Binary Tree
    Node root;

    /* Function to get the count of leaf nodes in a binary tree*/
    int getLeafCount()
    {
        return getLeafCount(root);
    }

    int getLeafCount(Node node)
    {
        if (node == null)
            return 0;
        if (node.left == null && node.right == null)
            return 1;
        else
            return getLeafCount(node.left) + getLeafCount(node.right);
    }
    void countDiffNodes(Node root){
        if(root==null){
            return ;
        }
        if(root.left==null && root.right==null){
            array[0]+=1;
        }
        if((root.left==null && root.right!=null) || (root.left!=null && root.right==null)){
            array[1]+=1;
        }
        if(root.left!=null && root.right!=null){
            array[2]+=1;
        }
        countDiffNodes(root.left);
        countDiffNodes(root.right);
        return ;
    }
    public static void main(String args[]) {
        BinaryTrees tree = new BinaryTrees();
        tree.root = new Node(1);
        tree.root.left = new Node(2);
        tree.root.right = new Node(3);
        tree.root.left.left = new Node(4);
        tree.root.left.right = new Node(5);
        tree.root.right.right=new Node(6);
        tree.root.right.right.right=new Node(7);
        System.out.println("The leaf count of binary tree is : " + tree.getLeafCount());
        tree.countDiffNodes(tree.root);
        System.out.println(Arrays.toString(tree.array));
    }

}


