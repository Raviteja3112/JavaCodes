package Maths;

public class AddBinary {
    public static void main(String[] args) {
        String a = "1010";
        String b = "1011";
        String c;

        int num=Integer.parseInt(a);



    }
}
