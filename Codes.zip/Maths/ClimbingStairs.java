package Maths;

public class ClimbingStairs {
    static int count=0;
    public static int stairCase(int n, int rem,String p) {
        if(n==rem){
            count+=1;
            System.out.println(p);
            return count;
        }
        if(rem>n){
            return 0;
        }
        stairCase(n,rem+1,p+"1");
        stairCase(n,rem+2,p+"2");
        return count;
    }
    public static void main(String[] args) {
        int n=3;
        stairCase(n, 0,"");
        System.out.println(count);
    }
}
