package Maths;

public class RomantoInteger {
    public static void main(String[] args) {
        String s = "LVIII";
        int sum = 0;
        char[] roman = {'I', 'V', 'X', 'L', 'C', 'D', 'M'};
        int[] values = {1,    5,   10, 50,  100,  500, 1000};

        s=s.replace("IV","IIII")
                .replace("IX","VIIII")
                .replace("XL","XXXX")
                .replace("XC","LXXXX")
                .replace("CD","CCCC")
                .replace("CM","DCCCC");

        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == 'M')
                sum+=1000;

            else if(s.charAt(i) =='D')
                sum+=500;
            else if(s.charAt(i)=='C')
                sum+=100;
            else if(s.charAt(i) =='L')
                sum+=50;
            else if(s.charAt(i) =='X')
                sum+=10;
            else if(s.charAt(i) =='V')
                sum+=5;
            else
                sum+=1;
        }
        System.out.println(sum);
    }
}
