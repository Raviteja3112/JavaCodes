package Trees;

import java.util.ArrayList;
import java.util.Arrays;

public class BinaryTree {
    public static void findChild(int i,char[] tree){
        if(i*2> tree.length){
            System.out.print("It is a leaf node");
        }
        else {
            int node = i * 2;
            System.out.print(tree[node - 1] + " " + tree[node]);
        }
    }
    public static void findParent(int i,char[] tree){
        if(i==1){
            System.out.print("It is root");
            return ;
        }
        int node=i/2;
        System.out.print(tree[node-1]);
    }
    public static int leafCount(char[] tree){
        if((tree.length&1)==0)
            return tree.length/2;
        return (tree.length/2)+1;
    }
    public static void treeDisplay(char[] tree){
        int i=1;
        while(i<tree.length){
            for (int j = i; j <i*2; j++) {
                if(j>tree.length)
                    break;
                System.out.print(tree[j-1]+" ");
            }
            System.out.println();
            i*=2;
        }
    }

    public static void main(String[] args) {
        char[] tree={'a','b','f','e','d','c','g'};
        for (int i =1; i <= tree.length ; i++) {
            System.out.print(tree[i-1]+"--> ");
            findParent(i,tree);
            System.out.println();
        }

        ArrayList<ArrayList<Integer>> list=new ArrayList<>();
        for (int i = 0; i <2; i++) {
            list.add(new ArrayList<>());
            for (int j = 0; j <3; j++) {
                list.get(i).add(j);
            }
        }

        for (ArrayList<Integer> list1:list) {
            System.out.println(list1);
        }
    }
}
