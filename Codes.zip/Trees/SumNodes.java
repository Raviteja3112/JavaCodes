package Trees;

class SumOfNodes {
    //Represent the node of binary tree
    public static class Node{
        int data;
        Node left;
        Node right;

        public Node(int data){
            //Assign data to the new node, set left and right children to null
            this.data = data;
            this.left = null;
            this.right = null;
        }
    }

    //Represent the root of binary tree
    public Node root;

    public SumOfNodes(){
        root = null;
    }

    //calculateSum() will calculate the sum of all the nodes present in the binary tree
    public int calculateSum(Node temp){
        if(temp == null) {
            return 1;
        }
        else {
           int left=calculateSum(temp.left);
           int right=calculateSum(temp.right);
           return temp.data *left * right;
        }
    }
    public int countInternal(Node root){
        if(root==null)
            return 0;
        if(root.left==null && root.right==null)
            return 0;
        return 1+ countInternal(root.left)+countInternal(root.right);
    }
}

public class SumNodes {
    public static void main(String[] args) {
        SumOfNodes bt = new SumOfNodes();
        //Add nodes to the binary tree

        bt.root = new SumOfNodes.Node(5);
        bt.root.left = new SumOfNodes.Node(2);
        bt.root.right = new SumOfNodes.Node(9);
        bt.root.left.left = new SumOfNodes.Node(1);
        bt.root.right.left = new SumOfNodes.Node(8);
        bt.root.right.right = new SumOfNodes.Node(6);
        bt.root.right.right.right = new SumOfNodes.Node(31);


        //Display the sum of all the nodes in the given binary tree
        System.out.println(bt.countInternal(bt.root));
    }
}
