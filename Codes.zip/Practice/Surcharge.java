package Practice;

public class Surcharge {
    public static void main(String[] args) {
        float dollarAmount = 10.50f;
        float centAmount = 0.50f;
        float totalAmount = dollarAmount + centAmount;
        System.out.println("Total amount: $" + totalAmount);
    }
}
