package Practice;

public class SumofLarge {
    public static void main(String[] args) {


        float num= ((float)6/32);
        System.out.println(num);
    }
}
