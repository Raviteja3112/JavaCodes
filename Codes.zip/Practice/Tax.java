package Practice;

public class Tax {
    public static void main(String[] args) {
        double tax_income=5500000d;

        double tax1=0;
        if(tax_income>1500000){
            tax1=tax_income*0.3;
        }
        else if (tax_income>=1250000) {
            tax1=tax_income*0.25;
        }
        else if (tax_income>=1000000) {
            tax1=tax_income*0.2;
        }
        else if (tax_income>=750000) {
            tax1=tax_income*0.15;
        }
        else if (tax_income>=500000) {
            tax1=tax_income*0.1;
        }
        else if (tax_income>=250000) {
            tax1=tax_income*0.05;
        }
        else {
            tax1=0;
        }

        double tax2=0;
        if(tax_income>50000000){
            tax2=tax1*0.37;
        }
        else if (tax_income>20000000) {
            tax2*=0.25;
        }
        else if (tax_income>10000000) {
            tax2=tax1*0.15;
        }
        else{
            if(tax_income>50000000){
                tax2=tax1*0.1;
            }
        }

        double total=(tax1+tax2)+(tax_income*0.04);
        System.out.println(total);
    }
}
