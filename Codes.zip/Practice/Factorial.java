package Practice;

import java.lang.reflect.Array;
import java.util.Arrays;

public class Factorial {
    public static void main(String[] args) {
        int[] arr = {0,1,2,3,4,5,6,7,8};
        Arrays.sort(arr);
        int[] bitsArray=new int[arr.length];
        for (int i = 0; i < arr.length; i++) {
            int count=0;
            while(arr[i]>0){
                if((arr[i]&1)==1){
                    count+=1;
                }
                arr[i]=arr[i]>>1;
            }
            bitsArray[i]=count;
        }

        for (int i = 0; i < arr.length; i++) {

            for (int j = 0; j < arr.length; j++) {

            }
        }

    }
}
