package Practice;

import javax.swing.*;
import java.awt.*;


public class SnakeAndLadderGame extends JPanel {

    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        int xPoints[] = {150, 250, 350};
        int yPoints[] = {150, 50, 150};

        g.setColor(Color.red);
        g.fillPolygon(xPoints, yPoints, 3);

        g.setColor(Color.blue);
        g.fillRect(150, 150, 200, 150);

        g.setColor(Color.yellow);
        g.fillRect(200, 200, 50, 100);

        g.setColor(Color.black);
        g.drawRect(150, 150, 200, 150);

        g.drawRect(200, 200, 50, 100);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("House");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 500);
        frame.add(new SnakeAndLadderGame());
        frame.setVisible(true);
    }
}

