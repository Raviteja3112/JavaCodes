package Practice;
import java.util.Arrays;

 class Student {
    int bdy;
    String name;
    int[] marks;
    int lucky;

    Student(){

    }
    Student(int bdy,String name,int[] marks){
        this.marks=new int[marks.length];
        this.bdy=bdy;
        this.name=name;
        for (int i = 0; i < marks.length; i++) {
            this.marks[i]=marks[i];
        }
    }


    public void deatailsOfStudent(){
        System.out.println("name: "+ name);
        System.out.println("bdy: "+ bdy);
        System.out.println(lucky+ " is a lucky number? "+ reverse(lucky));
        System.out.println(Arrays.toString(marks));
        System.out.println(calculateCGPA(marks));
        System.out.println();
    }

    protected float calculateCGPA(int[] marks){
            float sum=0;
            for (int eachSubMark:marks) {
                sum+=eachSubMark;
            }
            return (sum/ marks.length)/10;
    }

    public  boolean reverse(int num){
        int temp=num;
        int sum=0;
        while(num>0){
            int rem=num%10;
            sum=sum*10+rem;
            num/=10;
        }
        return temp==sum;
    }
    public void message(){
        System.out.println("In Student class");
    }

}

class B extends Student{
    @Override
    public void message(){
        System.out.println("In B class");
    }
    public void luckyNumber(){
        System.out.println("I am a lucky number");
    }
}

public class OOPS {
    public static void main(String[] args) {
        Student  obj=new B();
        obj.message();
    }
}
