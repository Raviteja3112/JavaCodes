package Practice;

class Students{
    Students(){
        System.out.println("Object has Created");
    }
    float name; //4
    int roll;  //2
    long phone;  //8
}

public class RectangleShape {
    public static void main(String[] args) {
        Students b=new Students();

    }
}
