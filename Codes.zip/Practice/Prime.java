package Practice;

import java.util.ArrayList;

public class Prime {
    public static boolean isPrime(int n){
        int i,m=n/2;
        if(n==0||n==1){
            return false;
        }else{
            for(i=2;i<=m;i++){
                if(n%i==0){
                    return false;
                }
            }
            return true;
        }
    }

    public static void main(String[] args) {
        ArrayList<Integer> list=new ArrayList<>();
        list.add(619);
        list.add(514);
        list.add(857);
        list.add(518);
        list.add(825);
        list.add(940);

        long sum=0;
        for (int i = 0; i < list.size(); i++) {
            if(isPrime(list.get(i))){
                sum+=list.get(i);
            }
        }
        System.out.println(sum);
    }
}
