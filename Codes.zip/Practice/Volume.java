package Practice;

import java.util.Scanner;

public class Volume {

    public static double calculateVolume(double radius,double height){
        double sphere=(4*Math.PI*Math.pow(radius,3))/3;
        double cone=(Math.pow(radius,2)*height*Math.PI)/3;
        if(height!=0){
            return cone;
        }
        return sphere;
    }

    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.println("Enter Radius: ");
        double radius=in.nextDouble();
        System.out.println("Enter Height: ");
        double height=in.nextDouble();
        System.out.printf("Volume is: %.2f\n",calculateVolume(radius,height));
    }
}
