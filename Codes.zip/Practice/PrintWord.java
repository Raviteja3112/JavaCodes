package Practice;

public class PrintWord {
    public static void main(String[] args) {
        int num=3124;

        int temp=num;
        int rev=0;
        while(temp>0){
            int rem=temp%10;
            rev=rev*10+rem;
            temp/=10;
        }

        while(rev>0){
            int rem=rev%10;
            if(rem==0){
                System.out.println("zero");
            }
        }

    }
}
