package Practice;

import java.util.Scanner;

public class Arrays {
    public static void insert(int num,int[] array,int index){
        for (int i = index; i <index+4 ; i++) {
            int rem=num%10;
            array[i]=rem;
            num/=10;
        }
    }

    public static void main(String[] args) {
        int a=8530,b=5620,c=7532;

        int[] array=new int[12];
        insert(a,array,0);
        insert(b,array,4);
        insert(c,array,8);

        int[] count=new int[10];
        for (int i = 0; i < array.length; i++) {
            count[array[i]]+=1;
        }

        int num=0;


        int min=0;
        for (int i = 0; i < array.length; i++) {
            if(count[i]>0){
                min=i;
                break;
            }
        }
        num=num*10+min;


        int max=0;
        for (int i = 9; i >=0;i--) {
            if(count[i]>0){
                max=i;
                break;
            }
        }
        num=num*10+max;



        int once=0;
        for (int i = 0; i < 10; i++) {
            if(count[i]==1){
                once=i;
                break;
            }
        }
        num=num*10+once;

        int twice=10;
        for (int i = 9; i>=0; i--) {
            if(count[i]>=2){
                twice=i;
                break;
            }
        }
        num=num*10+twice;

        System.out.println(num);


    }
}
