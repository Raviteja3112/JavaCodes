package Practice;

import jdk.swing.interop.SwingInterOpUtils;

import java.util.Scanner;

public class Stack {

    static int size=10;
    static int[] stack=new int[size];
    static int top=-1;
    public static void push(int num){
        if(top==size){
            System.out.println("Stack Overflow");
            return;
        }
        stack[++top]=num;
    }

    public static void pop(){
        if(top==-1){
            System.out.println("Error underflow, stack is Empty");
            return ;
        }
        System.out.println(stack[top]+" is Popped");
        top-=1;
    }

    public static void display(){
        System.out.print("Items on Stack: ");
        for (int i = 0; i <=top; i++) {
            System.out.print(stack[i]+" ");
        }
        System.out.println();
    }
    public static void purge(){
        if(top==-1){
            System.out.println("Stack is Empty");
            return;
        }
        System.out.println("Stack is Not Empty");
    }

    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        boolean loop=true;
        while (loop) {
            System.out.println("Stack Menu Prompt\n"+
                    "Type A to push a number to the stack\n" +
                    "Type B to pop a number from the stack\n" +
                    "Type C to output the top of the stack\n" +
                    "Type D to purge the stack\n" +
                    "Type E to Exit");

            char input=in.next().charAt(0);

            switch (input){
                case 'A':
                    boolean flag=true;
                    while (flag) {
                        System.out.println("Enter a number between 0 and 99 to push to the stack:");
                        int num = in.nextInt();
                        if (num >= 0 && num <= 99) {
                            push(num);
                            display();
                            flag=false;
                        } else {
                            System.out.println("Wrong input try again");
                        }
                    }
                    break;

                case 'B':
                    pop();
                    display();
                    break;
                case 'C':
                    System.out.println("Top of the stack: "+stack[top]);
                    break;
                case 'D':
                    purge();
                    break;
                case 'E':
                    loop=false;
                    break;

                default:
                    System.out.println("Choose correct option");
            }
        }



    }
}
