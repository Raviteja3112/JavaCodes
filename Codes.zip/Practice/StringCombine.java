package Practice;

import java.util.Scanner;

public class StringCombine {
    public static String combine(String s1,String s2){
        if(s1.length()==0 && s2.length()==0){
            return "Strings are Empty";
        }
        if(s1.length()==0 && s2.length()!=0){
            return s2;
        }
        if(s1.length()!=0 && s2.length()==0){
            return s1;
        }
        int i=0,j=0;
        String mergeString="";
        while(i!=s1.length() && j!=s2.length()){
            mergeString+=s1.charAt(i);
            mergeString+=s2.charAt(j);
            i++;
            j++;
        }
        if(i!=s1.length()){
            mergeString+=s1.substring(i);
        }
        if(j!=s2.length()){
            mergeString+=s2.substring(j);
        }
        return mergeString;
    }
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        String str1=in.next();
        String str2=in.next();
        System.out.println(combine(str1,str2));
    }
}
