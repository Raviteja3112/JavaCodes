package Practice;

import java.util.*;
import java.util.Arrays;
import java.util.Stack;

public class Exam {
    public static String isValid(int evenPlaceSum,int oddPlaceSum){
        if((evenPlaceSum+oddPlaceSum)%10==0)
            return "Valid";
        return "Invalid";
    }
    public static int sumofDoubleEvenPlace(int[] array){
        int start=0;
        if(array.length%2==0){
            start=0;
        }
        else{
            start=1;
        }
        int sumdouble=0;
        for (int i = start; i < array.length; i+=2) {
            int doubleit=array[i]*2;
            sumdouble+=getDigit(doubleit);
        }
        return sumdouble;
    }
    public static int getDigit(int doubleit){
        if(doubleit>9){
            return (doubleit-10)+1;
        }
        return doubleit;
    }
    public static int sumofOddplace(int[] array){
        int start=0;
        if(array.length%2==0){
            start=1;
        }
        else{
            start=0;
        }
        int oddSum=0;
        for (int i = start; i < array.length; i+=2) {

            oddSum+=array[i];
        }
        return oddSum;
    }


    public static void main(String[] args) {
       long num=4388576018402626l;
       long temp=num;
       int len=(int)Math.log10(num)+1;
       int[] array=new int[len];

        for (int i = len-1; i >=0; i--) {
            array[i]= (int) (temp%10);
            temp/=10;
        }
        System.out.println(isValid(sumofDoubleEvenPlace(array),sumofOddplace(array)));
    }
}