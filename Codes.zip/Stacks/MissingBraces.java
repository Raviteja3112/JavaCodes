package Stacks;

import java.util.Stack;

public class MissingBraces {
    public static String checkBraces(String code){
        Stack<Character> stack=new Stack<>();
        for(int i=0;i<code.length();i++){
            if(code.charAt(i)=='{'){
                stack.push('{');
            }
            else {
                if(code.charAt(i)=='}'){
                    if(stack.isEmpty()){
                        return "error";
                    }
                    stack.pop();
                }
            }
        }
        return "correct";
    }
    public static void main(String[] args) {
        String braces="public{}}";
        System.out.println(checkBraces(braces));
    }
}
