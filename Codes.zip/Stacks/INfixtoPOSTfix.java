package Stacks;

import java.util.Stack;

public class INfixtoPOSTfix {
    public static String evaluate(String eval){
        Stack<Character> stack=new Stack<>();


        for (int i=0;i<eval.length();i++){
            boolean ch=Character.isLetter(eval.charAt(i));
            if(!ch){
                char operator=eval.charAt(i);
            }
        }
        return " ";
    }
    public static void main(String[] args) {
        String eval="a+b*d-e/f=c=g";
        System.out.println(evaluate(eval));
    }
}
