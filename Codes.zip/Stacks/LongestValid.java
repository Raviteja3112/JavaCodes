package Stacks;

import java.util.Stack;

public class LongestValid {
    public static void main(String[] args) {
        String s = "()(()";

        Stack<Character> stack=new Stack<>();
        int count=0,untill=0;

        for (int i = 0; i < s.length(); i++) {
            if(stack.isEmpty()){
                stack.push(s.charAt(i));
            }
            else{
                if(s.charAt(i)=='(' ){
                    stack.push(s.charAt(i));
                }
                else{
                    if(stack.peek()=='(') {
                        stack.pop();
                        untill += 2;
                    }
                    else{
                        if(untill>count){
                            count=untill;
                        }
                        untill=0;
                    }
                }
            }
        }
        if(untill>count){
            count=untill;
        }
        System.out.println(count);
    }
}
