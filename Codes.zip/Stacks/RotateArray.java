package Stacks;

import java.util.Arrays;

public class RotateArray {
    public static void main(String[] args) {
        int[] array={1,2,3,4,5,6,7,8,9};
        int input1=9;
        int input2=2;
        int[] rotate=new int[array.length];

        int k=0;
        for(int i=input2;i< array.length;i++){
            rotate[k++]=array[i];
        }
        for(int i=0;i<input2;i++){
            rotate[k++]=array[i];
        }
        System.out.println(Arrays.toString(rotate));
    }
}
