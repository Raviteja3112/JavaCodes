package Stacks;

class MultiSackArray{
    private int elements;
    private int[] stack;
    private int sizeofEachStack;
    private int noofStack;
    int[] topStack;

    MultiSackArray(int elements,int sizeofEachStack){
        this.elements=elements;
        this.sizeofEachStack=sizeofEachStack;
        noofStack=elements/sizeofEachStack;
        stack=new int[elements];
        topStack=new int[noofStack];

        for(int i = 0; i < noofStack; i++) {
            topStack[i]=-1+i*sizeofEachStack;
        }

    }

    public  void push(int data,int stackno){
        if(topStack[stackno]==((stackno+1)*sizeofEachStack)-1){
            System.out.println("overflow occured at "+stackno+" stack");
            return;
        }
        int top=++topStack[stackno];
        stack[top]=data;
    }
    public  int pop(int stackno){
        if(topStack[stackno]==(stackno*sizeofEachStack)-1){
            System.out.println("underflow occured at "+stackno +" stack");
            return -1;
        }
        int data=stack[topStack[stackno]];
        topStack[stackno]--;
        return data;
    }

    public void display(int stackno){
        int inital=sizeofEachStack*stackno;

        while(inital<=topStack[stackno]){
            System.out.println(stack[inital++]);
        }
        System.out.println("Printed all values of "+stackno+" stack");
    }

}


public class MultiStackSingleArray {
    public static void main(String[] args) {
        MultiSackArray obj=new MultiSackArray(15,5);

        obj.push(31,0);
        obj.push(24,2);
        obj.push(69,1);
        obj.push(74,1);
        obj.push(59,0);
        obj.push(77,0);
        obj.pop(0);
        obj.pop(2);
        obj.pop(2);

        obj.display(0);
        obj.display(1);
        obj.display(2);

    }
}
