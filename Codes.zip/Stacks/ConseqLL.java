package Stacks;

import java.util.Arrays;
import java.util.Stack;

public class ConseqLL {
    public static void main(String[] args) {
        int[] array={1,3,4,2,9,2,3,1,10,6,3};
        int[] nextGreat=new int[array.length];
        int untillGreat=array[0],index=0;

        for (int i = 1; i < array.length; i++) {
            if(untillGreat<array[i]){
                while(index<i){
                    nextGreat[index++]=array[i];
                }
                untillGreat=array[i];
            }
        }
        System.out.println(Arrays.toString(nextGreat));


    }
}
