package Recursion;

public class NtoOne {
    public static void print(int n){
        if(n==0){
            return;
        }
        print(n-1);
        System.out.println(n);
    }

    static int factorial(int n){
        if(n==1){
            return 1;
        }
        return n*factorial(n-1);
    }

    static int sumOfDigits(int n){
        if(n<10){
            return n;
        }
        return (n%10)+sumOfDigits(n/10);
    }

    static int sumOfProduct(int n){
        if(n<10){
            return n;
        }
        return (n%10)*sumOfProduct(n/10);
    }

    static int reverseOfNumber(int n,int count){
        if(n<10){
            return n;
        }
        count=(int)Math.log10(n)+1;
        return (n%10)*(int)Math.pow(10,count-1)+reverseOfNumber(n/10,count);
    }

    static int palindrome(int n,int count){
        if(n<10){
            return n;
        }
        count=(int)Math.log10(n)+1;
        return (n%10)*(int)Math.pow(10,count-1)+reverseOfNumber(n/10,count);
    }

    static int countZeros(int n){
        if(n<10){
            return 0;
        }
        if(n%10==0){
            return 1+countZeros(n/10);
        }
        return  countZeros(n/10);

    }

    public static void main(String[] args) {

        System.out.println(countZeros(22000045));
    }
}
