package Recursion;

public class Fibonacci {
    public static long fibo(int n){
        long a;
        if(n<2){
            return n;
        }
        else{
            a=fibo(n-1)+fibo(n-2);
                return a;
        }
    }
    public static void main(String[] args) {
        int num=40;
        System.out.print("0 1 ");
        for(int i=2;i<=num;i++){
            System.out.println(fibo(i)+ " ");
        }

    }
}
