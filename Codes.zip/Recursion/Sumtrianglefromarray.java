package Recursion;

import java.util.Arrays;

public class Sumtrianglefromarray {
    public static void sumtrainingle(int[] nums){
        if(nums.length==0){
            return;
        }

        int[] array=new int[nums.length-1];
        for(int i=0;i< nums.length-1;i++){
            array[i]=nums[i]+nums[i+1];
        }
        sumtrainingle(array);
        System.out.println(Arrays.toString(nums));
    }

    public static void main(String[] args) {
        int[] nums={1,2,3,4,5};
        sumtrainingle(nums);
    }
}
