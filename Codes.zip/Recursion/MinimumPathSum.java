package Recursion;

import java.util.ArrayList;

public class MinimumPathSum {
    static int finalSum=Integer.MAX_VALUE;
    public static void minPath(int[][] grid,int r,int c,String p,int sum) {
        if(r== grid.length-1 && c==grid[0].length-1){
            if(sum<finalSum){
                finalSum=sum;
            }
            System.out.print(sum+" ");
            System.out.println(p);
            return;
        }
        if(r<grid.length-1){
            minPath(grid,r+1,c,p+grid[r+1][c],sum+grid[r+1][c]);
        }
        if(c< grid[0].length-1){
             minPath(grid,r,c+1,p+grid[r][c+1],sum+grid[r][c+1]);
        }
    }
    public static void main(String[] args) {
        int[][] grid = {{1,2,3},{4,5,6}};
        minPath(grid,0,0,""+grid[0][0],grid[0][0]);
        System.out.println(finalSum);
    }
}
