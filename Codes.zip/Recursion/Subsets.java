package Recursion;

public class Subsets {
    public static void subset(String s,String unanswer){
        if(s.length()==0){
            System.out.println(unanswer);
            return;
        }
        else{
            subset(s.substring(1),unanswer+s.charAt(0));
            subset(s.substring(1),unanswer);
        }
    }
    public static void main(String[] args) {
        String s="abc";
        subset(s,"");
    }
}
