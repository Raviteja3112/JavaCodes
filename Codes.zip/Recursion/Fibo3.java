package Recursion;

import java.util.Scanner;

public class Fibo3 {
    public static int fibonacci(int num){
        if(num<=3){
            if(num==1){
                return 1;
            }
            if(num==2){
                return 3;
            }
            return 2;
        }
        else{
            return fibonacci(num-1)+fibonacci(num-2)+fibonacci(num-3);
        }
    }
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        int num=input.nextInt();
        for(int i=0;i<num;i++){
            int n=input.nextInt();
            System.out.println(fibonacci(n));
        }
    }
}
