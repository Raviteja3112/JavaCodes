package Recursion;

import java.util.Arrays;

public class BubbleSort {
    static void bubbleSort(int[] nums,int start,int end){
        if(start==end){
            return;
        }
        if(nums[start]>nums[start+1]){
            int temp=nums[start];
            nums[start]= nums[start+1];
            nums[start+1]=temp;
        }
        if(start==end-1){
            bubbleSort(nums,0,end-1);
        }
        bubbleSort(nums,start+1,end);
    }
    public static void main(String[] args) {
        int[] nums={4,3,8,2,1};
        bubbleSort(nums,0,nums.length-1);
        System.out.println(Arrays.toString(nums));
    }
}
