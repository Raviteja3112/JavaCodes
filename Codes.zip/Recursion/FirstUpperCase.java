package Recursion;

public class FirstUpperCase {
    public static void firstCheck(String name){
        if(name.length()==0){
            return;
        }
        if(name.charAt(0)>='A' && name.charAt(0)<='Z'){
            System.out.println(name.charAt(0));
            return;
        }
        else{
            firstCheck(name.substring(1));
        }
    }
    public static void main(String[] args) {
        String name="raviTejaNandam";
        firstCheck(name);
    }
}
