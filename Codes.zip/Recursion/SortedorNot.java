package Recursion;

public class SortedorNot {
    static boolean check(int[] nums,int start){
        if(start== nums.length-1){
            return true;
        }
        if(nums[start]<=nums[start+1]){
            return check(nums,start+1);
        }
        return false;
    }
    public static void main(String[] args) {
        int[] nums={1,3,4,5,7,9,10,14,17};
        int start=0;
        System.out.println(check(nums,start));
    }
}
