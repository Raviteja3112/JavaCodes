package Recursion;

import java.util.*;
public class MazeProblem {
    public static void main(String[] args) {
        boolean[][] isVisited=new boolean[3][3];
        mazeNumbering("",new int[3][3],0,0,isVisited,1);
    }

    public static void mazeNumbering(String dir,int[][] path,int r,int c,boolean[][] isVisited,int counter) {
        if(isVisited[r][c]){
            return;
        }
        path[r][c]=counter;
        if (r == isVisited.length-1 && c == isVisited.length-1) {
            for(int[] nums:path){
                System.out.println(Arrays.toString(nums));
            }
            System.out.println(dir+" ");
            System.out.println();
            return;
        }

        isVisited[r][c]=true;
        if (c < isVisited.length-1) {
            mazeNumbering(dir+"R",path, r, c + 1, isVisited,counter+1);
        }
        if (r < isVisited.length-1) {
            mazeNumbering( dir+"D",path, r + 1, c, isVisited,counter+1);
        }
        if (r >0) {
            mazeNumbering( dir+"U",path, r - 1, c,isVisited,counter+1);
        }
        if (c >0) {
            mazeNumbering(dir+"L",path, r, c - 1, isVisited,counter+1);

        }
        isVisited[r][c]=false;
    }



    public static void mazeAllDiretion(String path,int r,int c,boolean[][] isVisited) {
        if(isVisited[r][c]){
            return;
        }
        if (r == isVisited.length-1 && c == isVisited.length-1) {
            System.out.println(path);
            return;
        }
        isVisited[r][c]=true;
            if (c < isVisited.length-1) {
                mazeAllDiretion(path +"R", r, c + 1, isVisited);
            }
            if (r < isVisited.length-1) {
                mazeAllDiretion( path+"D", r + 1, c, isVisited);
            }
            if (r >0) {
                mazeAllDiretion( path+"U", r - 1, c,isVisited);
            }
            if (c >0) {
                mazeAllDiretion(path+"L", r, c - 1, isVisited);

            }
        isVisited[r][c]=false;
    }
}
