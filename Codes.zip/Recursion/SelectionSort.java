package Recursion;

import java.util.Arrays;

public class SelectionSort {
    static void selectionSort(int[] nums,int start,int counter,int min,int index){
        if(counter== nums.length-1){
            return;
        }
        if(min>nums[start]){
            min=nums[start];
            index=start;
        }
        if(start== nums.length-1){
            int temp=nums[counter];
            nums[counter]=min;
            nums[index]=temp;
            selectionSort(nums,counter+1,counter+1,nums[counter+1],counter+1);
        }
        else{
            selectionSort(nums,start+1,counter,min,index);
        }

    }
    public static void main(String[] args) {
        int[] nums={31,23,54,634,1,8,6,9};
        selectionSort(nums,0, 0,nums[0],0);
        System.out.println(Arrays.toString(nums));
    }
}
