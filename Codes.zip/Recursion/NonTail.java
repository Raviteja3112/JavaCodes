package Recursion;

public class NonTail {
    static String[] dp=new String[6];
    public static void call(int n){
        if(n<=1) {
            dp[0]=" ";
            dp[1]=" ";
            return ;
        }
        dp[n]=Integer.toString(n-2);
        call(n-1);
        dp[n]=dp[n]+dp[n-1]+n+dp[n-2]+dp[n];
    }
    public static void call1(int n){
        if(n<=1) {
            dp[0]=" ";
            dp[1]=" ";
            return ;
        }
        call(n-1);
        dp[n]=dp[n-1]+n+dp[n-1];
    }
    public static void main(String[] args) {
        call(5);
        System.out.println(dp[5]);
    }
}
