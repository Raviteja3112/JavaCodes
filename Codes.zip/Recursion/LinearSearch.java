package Recursion;

public class LinearSearch {
    static int search(int[] nums,int target,int start){
        if(nums[start]==target){
            return start;
        }
        if(start== nums.length-1)
            return -1;
        return search(nums,target,start+1);
    }
    public static void main(String[] args) {
        int[] nums={1,3,4,5,7,9,10,14,17};
        System.out.println(search(nums,19,0));
    }
}
