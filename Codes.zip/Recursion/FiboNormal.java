package Recursion;

public class FiboNormal {
    public static void main(String[] args) {
        long a=0,b=1;
        int n=40;
        while(n>2){
            long c=a+b;
            System.out.println(c);
            long temp=b;
            b=c;
            a=temp;
            n--;
        }
    }
}
