package Recursion;

import java.util.ArrayList;
import java.util.Arrays;

public class Permutations {
    public static ArrayList<String> permutation(String s, String un, ArrayList<String > list){
        if(s.length()==0){
            list.add(un);
            return list;
        }
        else{
            for(int i=0;i<=un.length();i++){
                String first=un.substring(0,i);
                char ch=s.charAt(0);
                String sec=un.substring(i);
                permutation(s.substring(1),first+ch+sec,list);
            }
        }
        return list;
    }
    public static void main(String[] args) {
        String s="123";
        ArrayList<String> list =permutation(s,"",new ArrayList<>());
        String[] s2=list.toArray(new String[0]);
        Arrays.sort(s2);
        String check="132";

        for (int i = 0; i < s2.length; i++) {
            if(s2[i].equals(check)){
                System.out.println(i+1);
            }
        }

    }
}
