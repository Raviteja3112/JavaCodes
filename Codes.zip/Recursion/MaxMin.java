package Recursion;

import java.util.Arrays;

public class MaxMin {
    public static int[] minmax(int[] nums,int max,int min,int index){
        if(nums.length==index){
            return new int[]{min,max};
        }
        if(nums[index]>max){
            max=nums[index];
        }
        if(nums[index]<min){
            min=nums[index];
        }
        return minmax(nums,max,min,index+1);
    }
    public static void main(String[] args) {
        int[] arr = {1, 4, 45, 6, 10, -8};
        int min=arr[0],max=arr[0];
        System.out.println(Arrays.toString(minmax(arr,min,max,1)));
    }
}
