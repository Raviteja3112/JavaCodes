package Recursion;

public class StringReverse {
    public static String stringrev(String name){
        if(name.isEmpty()){
            return "";
        }
        return  stringrev(name.substring(1))+name.charAt(0);
    }
    public static void main(String[] args) {
        String name="Ravi";
        System.out.println(stringrev(name));
    }
}
