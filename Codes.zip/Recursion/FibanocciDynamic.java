package Recursion;

public class FibanocciDynamic {
    public static int fibo(int n,int[] nums){
        int a;
        if(n<2){
            nums[n]=n;
            return n;
        }
        else{
            if(nums[n]==0){
                a=fibo(n-1,nums)+fibo(n-2,nums);
                return a;
            }
            else{
                return nums[n];
            }
        }

    }

    public static void main(String[] args) {
        int num=40;
        int[] array=new int[num+1];
        System.out.print("0 1 ");
        for(int i=2;i<=num;i++){
            System.out.println(fibo(i,array)+ " ");
        }

    }
}
