package DAC;

public class PowerofElement {
    public static int power(int base,int expo){
        if(expo==0)
            return 1;
        if(expo==1){
            return base;
        }
        int divide=expo/2;
        int mul=power(base,divide);
        if(expo%2==0)
            return mul*mul;
        return mul*mul*base;
    }

    public static void main(String[] args) {
        for (int i = 0; i <=10; i++) {
            System.out.println("2^"+i+"="+power(2,i));
        }
    }
}
