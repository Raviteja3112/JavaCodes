package DAC;

import java.util.Arrays;

public class MinMax {
    public static int max(int[] array,int start,int end){
        if(start==end){
            return array[start];
        }

        int divide=start+(end-start)/2;

        int leftmax=max(array,start,divide);
        int rightmax= max(array,divide+1,end);

        return Math.max(leftmax,rightmax);
    }
    public static int[] combine(int[] array1,int[] array2){
        int max,min;
        if(Math.max(array1[0],array1[1])>Math.max(array2[0],array2[1])){
            max=Math.max(array1[0],array1[1]);
        }
        else{
            max=Math.max(array2[0],array2[1]);
        }
        if(Math.min(array1[0],array1[1])>Math.min(array2[0],array2[1])){
            min=Math.min(array1[0],array1[1]);
        }
        else{
            min=Math.min(array2[0],array2[1]);
        }
        return new int[]{max,min};
    }

    public static int[] minmax(int[] array,int start,int end){
        if(start==end){
            return new int[]{array[start],array[start]};
        }
        if(end-start==1){
            return new int[]{array[start],array[end]};
        }

        int divide=start+(end-start)/2;

        int[] array1=minmax(array,start,divide);
        int[] array2= minmax(array,divide+1,end);

        return combine(array1,array2);
    }

    public static void main(String[] args) {
        int array=max(new int[]{0,1,1,2,1,3,2,3},0,7);
        System.out.println(array);
    }
}
