package DAC;

import java.util.Arrays;

public class QuickSort {
    public static void swap(int[] array,int i,int j){
        int temp=array[i];
        array[i]=array[j];
        array[j]=temp;
    }
    public static int partition(int[] array,int p,int q){
        if(p==q){
            return p;
        }
        int x=array[p];
        int i=p;
        for(int j=p+1;j<=q;j++){
            if(array[j]<=x){
                i++;
                swap(array,i,j);
            }
        }
        swap(array,i,p);
        return i;
    }
    public static int[] quickSort(int[] array,int p,int q){
        if(p>=q){
            return array;
        }
        int pivot=partition(array,p,q);
        quickSort(array,p,pivot-1);
        quickSort(array,pivot+1,q);
        return array;
    }

    public static void main(String[] args) {
        int[] array={50,80,90,15,25,35,150,11};

        System.out.println(Arrays.toString(quickSort(array,0, array.length-1)));
    }
}
