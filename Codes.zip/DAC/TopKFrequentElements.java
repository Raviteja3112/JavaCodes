package DAC;

import java.util.Arrays;

public class TopKFrequentElements {
    public static void main(String[] args) {

        int[] nums={1,1,1,2,2,3};
        int k=2;

        Arrays.sort(nums);
        int[] array=new int[nums.length];

        int count=0;
        for(int i=0;i<nums.length-1;i++){
            if(nums[i]==nums[i+1]){
                count+=1;
            }
            else{
                array[i]=count;
                count=0;
            }
        }

    }
}
