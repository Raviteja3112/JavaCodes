package DAC;

import java.util.Stack;

class DFT{
    boolean[][] graph;
    boolean[] visited;
    int nodes;
    DFT(int nodes){
        this.nodes=nodes;
        visited=new boolean[nodes];
        graph=new boolean[nodes][nodes];
    }

    public void insert(int i,int ...j){
        for (int num:j) {
            graph[i][num]=true;
            graph[num][i]=true;
        }
    }

    public void traverse(int startnode){
        Stack<Integer> stack=new Stack<>();
        stack.add(startnode);
        visited[startnode]=true;
        while(!stack.isEmpty()){
            int poped=stack.pop();
            System.out.println((char)(poped+65));
            for (int i = 0; i <this.nodes; i++) {
                if(graph[poped][i]==true && visited[i]==false){
                    stack.add(i);
                    visited[i]=true;
                }
            }
        }
    }

}

public class DepthFirstTraversal {
    public static void main(String[] args) {
        DFT graph=new DFT(7);
        graph.insert(0,1,2,3);
        graph.insert(1,4);
        graph.insert(2,4,5);
        graph.insert(3,5);
        graph.insert(4,6);
        graph.insert(5,6);

        graph.traverse(1);

    }
}
