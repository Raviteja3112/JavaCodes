package DAC;

import java.util.ArrayDeque;

import java.util.Queue;

class Graph{
    private int nodes;
    static int[][] graph;
    boolean[] isVisited;
    Graph(int nodes){
        this.nodes=nodes;
        graph=new int[this.nodes][this.nodes];
        isVisited=new boolean[this.nodes];
    }
    public  void breathFirstSearch(int startNode){
        Queue<Integer> queue=new ArrayDeque<>();
        queue.add(startNode);
        isVisited[startNode]=true;

        do {
            char num=(char)(queue.element()+97);
            System.out.print(num+" ");
            int curNode= queue.element();
            for (int i = 0; i < graph.length; i++) {
                if (graph[curNode][i] == 1 && !isVisited[i]) {
                    queue.add(i);
                    isVisited[i]=true;
                }
            }
            queue.remove();
        }while(!queue.isEmpty());
        System.out.println();

    }

    public void insert(int i,int j){
        graph[i][j]=1;
        graph[j][i]=1;
    }

    public void displayGraph(){
        for (int i = 0; i <nodes ; i++) {
            for (int j = 0; j <nodes; j++) {
                System.out.print(graph[i][j]+" ");
            }
            System.out.println();
        }
    }

}

public class GraphBFT {
    public static void main(String[] args) {
        Graph graph=new Graph(10);

        graph.insert(0,1);
        graph.insert(0,3);
        graph.insert(1,2);
        graph.insert(2,3);
        graph.insert(4,5);
        graph.insert(4,6);
        graph.insert(5,6);
        graph.insert(7,8);
        graph.insert(9,9);

        graph.breathFirstSearch(0);

    }
}
