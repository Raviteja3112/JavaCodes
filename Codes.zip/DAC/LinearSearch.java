package DAC;

public class LinearSearch {
    public static void main(String[] args) {
        int[] array={50,70,60,19,29,39,11,21,81,600,42,490};
        System.out.println(search(array,42,0));
    }

    private static int search(int[] array,int key,int index) {
        if(array[index]==key)
            return index;
        return search(array,key,index+1);
    }


}
