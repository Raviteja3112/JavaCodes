package DAC;

public class SelectionProcedure {
    public static int selectionProc(int[] array,int p,int q,int k){
        if(p>=q){
            return array[p];
        }
        int pivot=QuickSort.partition(array, p, q);
        if(pivot+1==k){
            return array[pivot];
        }
        else{
            if(k<pivot+1){
                return selectionProc(array,p,pivot-1,k);
            }
            else{
                return selectionProc(array, pivot+1, q, k);
            }

        }
    }

    public static void main(String[] args) {
        int[] array={65,80,30,60,40,20,88,98,44,32};

        for (int i = 0; i < array.length; i++) {
            System.out.println(selectionProc(array,0, array.length-1,i+1));
        }


    }
}
