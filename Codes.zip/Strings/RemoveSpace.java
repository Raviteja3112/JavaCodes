package Strings;

import java.util.*;

public class RemoveSpace {
    public static char[] number(int[] input1){


        char[] result=new char[input1.length];
        for (int i = 0; i < input1.length ; i++) {
            int count=0;
            for (int j = 0; j < input1.length ; j++) {
                if((i!=j)&& input1[i]>input1[j]){
                    count+=1;
                }
            }
            result[i]=(char)(count+97);
        }
        return result;


    }

    public static void main(String[] args) {
        int[] input1={10,1,2,3};
        System.out.println(number(input1));
    }
}
