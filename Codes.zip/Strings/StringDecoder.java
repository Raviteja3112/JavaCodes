package Strings;

public class StringDecoder {
    public static void main(String[] args) {
        String name="10110111";


        String[] array=name.split("0");
        name="";
        for (int i = 0; i < array.length; i++) {
            name+=(char)(array[i].length()+64);
        }
        System.out.println(name);





    }
}
