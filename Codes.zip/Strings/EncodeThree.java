package Strings;

import java.util.Arrays;

public class EncodeThree {
    public static String[] split(String input){
        String[] name=new String[3];
        int len=input.length()/3;
        int start=0,end=len;
        if(input.length()%3==0){
            for (int i = 0; i < 3; i++) {
                name[i]=input.substring(start,end);
                start=end;
                end+=3;
            }
        }
        else{
            if(input.length()%3==1){
                name[0]=input.substring(start,end);
                name[1]=input.substring(end,end+end+1);
                start=end+end+1;
                name[2]=input.substring(start);
            }
            else{
                name[0]=input.substring(start,end+1);
                start=end+1;
                name[1]=input.substring(start,start+start-1);
                start=start+start-1;
                name[2]=input.substring(start);
            }
        }
        return name;
    }

    public static void main(String[] args) {
        String input1="John";
        String input2="Johny";
        String input3="Janardhan";

        String[] name1,name2,name3;
        name1=split(input1);
        name2=split(input2);
        name3=split(input3);
        String output1=name1[0]+name2[0]+name3[0];
        String output2=name1[1]+name2[1]+name3[1];
        String output3=name1[2]+name2[2]+name3[2];

        String op="";
        for (int i = 0; i < output3.length(); i++) {
            char ch=output3.charAt(i);
            if(Character.isUpperCase(ch)){
                op+=Character.toLowerCase(ch);
            }
            else{
                op+=Character.toUpperCase(ch);
            }
        }
        System.out.println(output1+ "\n" +output2 + " \n" + op);
    }
}

