package Strings;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;

public class Code1 {
    static int checkDigit(int num){
        int digit=0;
        boolean flag=true;
        while(flag) {
            while (num > 0) {
                int rem = num % 10;
                digit += rem;
                num /= 10;
            }
            if(digit<10 && digit!=0){
                flag=false;
            }
            else{
                num=digit;
            }
            if(digit==0){
                return -1;
            }
        }
        return digit;
    }


    public static void main(String[] args) throws IOException {
        //int[] arr1={101,101,610,447,389};
        //int[] arr2={610,4,101,4,101};

        //String arr1="101,101,610,447,389";
        //String arr2="610,4,101,4,101";

        InputStreamReader ir=new InputStreamReader(System.in);
        BufferedReader br=new BufferedReader(ir);
        String[] str1=br.readLine().split(",");
        int a= str1.length;
        int[] arr1=new int[a];
        int q;
        for (q=0;q<a;q++){
            arr1[q]=Integer.parseInt(str1[q]);
        }

        ir=new InputStreamReader(System.in);
        br=new BufferedReader(ir);
        String[] str2=br.readLine().split(",");
        a= str2.length;
        int[] arr2=new int[a];
        for (q=0;q<a;q++){
            arr2[q]=Integer.parseInt(str2[q]);
        }


        ArrayList<Integer> list=new ArrayList<>();
        ArrayList<Integer> list2=new ArrayList<>();
        for (int i = 0; i < arr1.length; i++) {
            list.add(arr1[i]);
        }
        for (int i = 0; i < arr2.length; i++) {
            list2.add(arr2[i]);
        }
        int[] array=new int[Math.max(arr1.length,arr2.length)];
        int k=-1;
        for (int i = 0; i < list.size(); i++) {
            if(list2.contains(list.get(i))){
                array[++k]= list.get(i);
            }
        }
        if(k==-1){
            System.out.println("-1");
        }
        else {
            Arrays.sort(array, 0, k );
            int digit=checkDigit(array[0]);
            if (digit == -1) {
                System.out.println("-1");
            }
            else {
                Arrays.sort(arr1);
                Arrays.sort(arr2);
                int start = arr1.length - digit;
                int[] num1 = new int[digit];
                int[] num2 = new int[digit];
                k = 0;
                for (int i = start; i < arr1.length; i++) {
                    num1[k++] = arr1[i];
                }
                System.out.println(Arrays.toString(num1));

                k = 0;
                start = arr2.length - digit;
                for (int i = start; i < arr2.length; i++) {
                    num2[k++] = arr2[i];
                }
                System.out.println(Arrays.toString(num2));
            }
        }
    }
}
