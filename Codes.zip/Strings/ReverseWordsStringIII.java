package Strings;

import java.util.Arrays;

public class ReverseWordsStringIII {
    public static String reverse(String name){
        String revname="";
        for (int i = name.length()-1; i >=0 ; i--) {
            revname+=name.charAt(i);
        }
        return revname;
    }

    public static void main(String[] args) {
        String s = "Let's take LeetCode contest";
        String[] names=s.split(" ");
        System.out.println(Arrays.toString(names));

        String revname="";
        for (int i = 0; i < names.length; i++) {
            revname+=reverse(names[i]);
            if(i!= names.length-1){
                revname+=" ";
            }
        }

        System.out.println(revname);
    }
}
