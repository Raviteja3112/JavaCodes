package Strings;

import java.util.Stack;

public class PostfixCalc {
    public static void main(String[] args) {
        String sum="74-";
        Stack<Integer> list=new Stack<>();

        for (int i = 0; i < sum.length(); i++) {
            char ch=sum.charAt(i);
            switch (ch){
                case '+':
                    list.push(list.pop()+list.pop());
                    break;
                case '-':
                    list.push(list.pop()-list.pop());
                    break;
                case '/':
                    list.push(list.pop()/list.pop());
                    break;
                case '*':
                    list.push(list.pop()*list.pop());
                    break;
                    default:
                        list.push(Character.getNumericValue(ch));
            }
        }
        System.out.println(list.pop());
    }
}
