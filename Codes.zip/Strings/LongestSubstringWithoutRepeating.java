package Strings;

public class LongestSubstringWithoutRepeating {
    public static void main(String[] args) {
        String s1 = "ab", s2 = "eidbaooo";


    }
}
