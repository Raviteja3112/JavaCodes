package Strings;

import java.util.Arrays;
import java.util.Scanner;

public class Code2 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        String alphanum =input.nextLine();

        String alpha = "";
        String num = "";

        for (int i = 0; i < alphanum.length(); i++) {
            char ch = alphanum.charAt(i);
            if (ch >= 'a' && ch <= 'z' || ch >= 'A' && ch <= 'Z') {
                alpha += Character.toString(alphanum.charAt(i));
            } else {
                num += Character.toString(alphanum.charAt(i));
            }
        }

        if (alpha.length() == 0 || num.length() == 0) {
            System.out.println("-1");
        }
        else {
            char[] tempalpha = alpha.toCharArray();
            Arrays.sort(tempalpha);
            char[] tempnum = num.toCharArray();
            Arrays.sort(tempnum);

            alpha = String.copyValueOf(tempalpha);
            num = String.copyValueOf(tempnum);
            System.out.println(alpha);
            System.out.println(num);
            int afi = alphanum.indexOf(alpha.charAt(0));
            int afl = alphanum.indexOf(alpha.charAt(alpha.length() - 1));
            int alpharesult = afi > afl ? afi - afl : afl - afi;

            int nfi = alphanum.indexOf(num.charAt(0));
            int nfl = alphanum.indexOf(num.charAt(num.length() - 1));
            int numresult = nfi > nfl ? nfi - nfl : nfl - nfi;

            int sum = 0;
            for (int i = 0; i < num.length(); i++) {
                sum += Integer.parseInt(String.valueOf(num.charAt(i)));
            }

            System.out.println(alpha + "" + alpharesult + ":" + sum + "" + numresult);
        }
    }
}
