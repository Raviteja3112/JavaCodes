package Strings;

import java.util.ArrayList;

public class SubsetsReursion {
    public static void subsets(String name,String addSkip){
        if(name.length()==0){
            System.out.println(addSkip);
            return;
        }
        subsets(name.substring(1),addSkip+name.charAt(0));
        subsets(name.substring(1),addSkip);
    }
    public static ArrayList<String> subsets(String name, String addSkip,ArrayList<String> list){
        if(name.length()==0){
            list.add(addSkip);
            return list;
        }
        subsets(name.substring(1),addSkip+name.charAt(0),list);
        subsets(name.substring(1),addSkip,list);
        return list;
    }
    public static void main(String[] args) {
        ArrayList<String> list=new ArrayList<>();
        subsets("abc","",list);
        System.out.println(list);
    }
}
