package Strings;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Stack;

public class RemoveDupWord {
    public static void main(String[] args) {
        Stack<String> in=new Stack<>();
        in.push("Man");
        in.push("Wall");
        in.push("Walky");
        in.push("Sheera");
        in.push("Rio");

        Stack<String> out=new Stack<>();
        Stack<String> temp1=new Stack<>();
        Stack<String> temp2=new Stack<>();
        while(!in.isEmpty()){
            String value=in.pop();
            temp1.push(value);
        }
        while(!temp1.isEmpty()){
            String str=temp1.pop();
            for (int i = 0; i < str.length()-1; i++) {
                if(str.substring(i,i+1).equals(str.substring(i+1,i+2))){
                    temp2.push(str);
                }
            }
        }
        while(!temp2.isEmpty()){
            out.push(temp2.pop());
        }
        System.out.println(out);
    }
}
