package Strings;

import java.util.Arrays;
public class Sample {

    public static void main(String[] args) {
        String sentence="This is a sample sentence";
        String[] names=sentence.split(" ");
        String result="";
        for (int i = 0; i < names.length; i++) {
            char first = names[i].charAt(0);
            char last = names[i].charAt(names[i].length() - 1);
            String each = names[i];
            if (each.length() > 1) {
                String eachname = each.substring(1, each.length() - 1);
                if (eachname.length() != 0) {
                    char[] sub = eachname.toCharArray();
                    if ((i + 1) % 2 != 0) {
                        Arrays.sort(sub);
                        int n = sub.length;
                        char t;
                        for (int j = 0; j < n / 2; j++) {
                            t = sub[j];
                            sub[j] = sub[n - j - 1];
                            sub[n - j - 1] = t;
                        }
                    } else {
                        Arrays.sort(sub);
                    }
                    String concat = new String(sub);
                    System.out.println(concat);
                    String attach = first + concat + last + " ";
                    result = result + attach;
                } else {
                    result +=first + last+" ";
                }
            }
            else {
                result += first+" ";
            }
        }
        System.out.println(result);
    }
}
