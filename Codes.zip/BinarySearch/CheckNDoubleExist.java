package BinarySearch;

public class CheckNDoubleExist {
    public static void main(String[] args) {
        int[] arr = {10,2,5,3};

        for(int i=0;i< arr.length;i++){
            int target=arr[i]*2;
            for(int j=0;j<arr.length;j++){
                if(arr[j]==target){
                    System.out.println(arr[i]);
                    break;
                }
            }
        }
    }
}
