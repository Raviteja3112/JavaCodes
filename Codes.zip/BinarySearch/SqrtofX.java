package BinarySearch;

public class SqrtofX {
    public static void main(String[] args) {
        int target = 68;
        int start=0,end=target;

        while(start<=end){
            int mid=start+(end-start)/2;
            if(mid*mid==target){
                System.out.println(mid);
                break;
            }
            if(mid*mid>target){
                end=mid-1;
            }
            else {
                start=mid+1;
            }
        }
        if(start*start<target){
            System.out.println(start);
        }

    }
}
