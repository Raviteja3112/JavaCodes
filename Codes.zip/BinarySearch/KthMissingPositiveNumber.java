package BinarySearch;

public class KthMissingPositiveNumber {
    public static void main(String[] args) {
        int[] arr = {2,3,4,7,11};
        int k = 5;

        if(arr[arr.length-1]== arr.length){
            System.out.println(arr[arr.length-1]+k);
        }
       int start=0,end= arr.length-1;
        while(start<=end){
            int mid=start+(end-start)/2;
            if(arr[mid]-(mid+1)<k){
                start=mid+1;
            }
            else{
                end=mid-1;
            }
        }

        System.out.println(end);
        System.out.println(arr[end]);
        int miss=k-(arr[end]-(end+1));
        System.out.println(arr[end]+miss);
    }
}
