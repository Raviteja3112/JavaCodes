package BinarySearch;

public class ElementIndex {
    public static int find(int[] array,int start,int end){
        if(start==end){
            if(start==array[start]){
                return start;
            }
            else{
                return -1;
            }
        }
        else{
            int mid=(start+end)/2;
            if(array[mid]==mid){
                return mid;
            }
            else{
                if(array[mid]<mid){
                    return find(array,mid+1,end);
                }
                else{
                    return find(array,start,mid-1);
                }
            }
        }
    }

    public static void main(String[] args) {
        int[] array={-10,-8,-5,-2,0,2,3,5,8,20,30,40,80,90,100};
        System.out.println(find(array,0,array.length));
    }
}
