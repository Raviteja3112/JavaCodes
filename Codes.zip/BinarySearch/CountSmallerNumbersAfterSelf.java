package BinarySearch;

public class CountSmallerNumbersAfterSelf {
    public static void main(String[] args) {
        int[] nums = {10,9,3,5,2,6,1};

    }
}
