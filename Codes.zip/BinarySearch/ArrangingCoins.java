package BinarySearch;

public class ArrangingCoins {
    public static void main(String[] args) {
        int num=10;
        int start=1,end=num;
        int coinSum=0;

        while(start<=end){
            int mid=start+(end-start)/2;
            coinSum=(mid*(mid+1))/2;

            if(coinSum==num){
                System.out.println(coinSum);
            }
            else{
                if(coinSum>num){
                    end=mid-1;
                }
                else{
                    start=mid+1;
                }
            }
        }
    }
}
