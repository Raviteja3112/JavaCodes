package BinarySearch;

public class CountNegativeNumbersSortedMatrix {
    public static int search(int[] grid){
        int start=0,end= grid.length-1;

        while(start<=end){
            int mid=start+(end-start)/2;
            if(grid[mid]>=0){
                start=mid+1;
            }
            else{
                end=mid-1;
            }
        }
        System.out.println(start);

        if(start>=0 && start<=grid.length-1)
            return grid.length-1-start+1;

        return 0;
    }
    public static void main(String[] args) {
        int[][] grid = {{4,3,2,-1},{3,2,1,-1},{1,1,-1,-2},{-1,-1,-2,-3}};

        int count=0;
        for(int i=0;i< grid.length;i++){
            count+=search(grid[i]);
        }
        System.out.println(count);
    }
}
