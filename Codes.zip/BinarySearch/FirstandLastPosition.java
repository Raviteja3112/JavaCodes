package BinarySearch;

import java.util.ArrayList;
import java.util.Arrays;

public class FirstandLastPosition {
    public static int[] find(int[] nums,int target){
        int first=-1,last=-1;
        for (int i = 0; i < nums.length; i++) {
            if(target==nums[i] && first==-1){
                first=i;
            }
            if(target==nums[i]){
                last=i;
            }
        }

        return new int[]{first,last};
    }
    public static void main(String[] args) {
        int[] nums = {5,7,7,8,8,10};
        int target = 8;
        System.out.println(Arrays.toString(find(nums,target)));
    }
}
