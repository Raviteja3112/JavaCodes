package BinarySearch;

public class SearchRotatedSortedArrayII {
    public static int findHighestPeak(int[] nums){
        int start=0,end=start*2+1;
        if(end>= nums.length){
            end= nums.length-1;
        }
        while(start<=nums.length-1 && nums[start]<=nums[end]){
            start=end;
            end=start*2+1;
            if(end>= nums.length){
                end= nums.length-1;
            }
        }
        for(int i=start;i<end;i++){
            if(nums[i]>nums[i+1]){
                System.out.println(i);
                return i;
            }
        }
        return -1;
    }

    public static boolean binarySearch(int[] nums,int start,int end,int target){
        while(start<=end){
            int mid=start+(end-start)/2;
            if(nums[mid]==target){
                return true;
            }
            else{
                if(nums[mid]>target){
                    end=mid-1;
                }
                else{
                    start=mid+1;
                }
            }
        }
        return false;
    }
    public static void main(String[] args) {

        int[] nums = {1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1};
        int target = 0;

        int highPeak=findHighestPeak(nums);
        boolean check=binarySearch(nums,0,highPeak,target);
        if(check==false){

            check=binarySearch(nums,highPeak+1,nums.length-1,target);
        }
        System.out.println(check);
    }
}
