package BinarySearch;

import java.util.Arrays;

public class SumofElements {
    public static int find(int[] array,int start,int end,int target){
        if(end==start){
            if(array[start]==target)
                return array[start];
            else
                return -1;
        }
        else{
            int mid=(start+end)/2;
            if(array[mid]==target){
                return array[mid];
            }
            else{
                if(array[mid]<target){
                    return find(array,mid+1,end,target);
                }
                else{
                    return find(array,start,mid-1,target);
                }
            }
        }
    }

    public static void main(String[] args) {
        int[] array={100,200,300,400,500,600,700,800,900};
        int target=1300;
        /*
        for (int i = 0; i < array.length; i++) {
            int result=find(array,i+1, array.length, target-array[i]);
            if(result!=-1){
                System.out.println(array[i]+" "+result);
                break;
            }
        }
         */
        int start=0,end=array.length-1;
        while(start<end){
            int sum=array[start]+array[end];
            if(sum==target){
                System.out.println(array[start]+" "+array[end]);
                break;
            }
            else{
                if(sum<target)
                    start++;
                else
                    end--;
            }
        }

    }
}
