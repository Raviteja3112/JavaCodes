package BinarySearch;

public class FindMountainArray {
    public static int binarySearch2(int start,int end,int[] mountainArr,int target){
        while(start<=end){
            int mid=start+(end-start)/2;
            if(mountainArr[mid]==target){
                return mid;
            }
            else{
                if(mountainArr[mid]<target){
                    end=mid-1;
                }
                else{
                    start=mid+1;
                }
            }
        }
        return -1;
    }
    public static int binarySearch(int start,int end,int[] mountainArr,int target){
        while(start<=end){
            int mid=start+(end-start)/2;
            if(mountainArr[mid]==target){
                return mid;
            }
            else{
                if(mountainArr[mid]<target){
                    start=mid+1;
                }
                else{
                    end=mid-1;
                }
            }
        }
        return -1;
    }
    public static int peakIndex(int[] mountainArr){
        int start=0,end=mountainArr.length-1;
        int mid=0;
        while(start<end) {
            mid=start+(end-start)/2;
            if (mountainArr[mid] > mountainArr[mid - 1]) {
                start = mid + 1;
            } else {
                end = mid - 1;
            }
        }
        if(mountainArr[mid]<mountainArr[mid-1]){
            return mid-1;
        }
        return mid;
    }
    public static void main(String[] args) {
        int[] mountainArr = {1,5,2};
        int target = 2;
        int peakIndex=peakIndex(mountainArr);
        System.out.println("peak index: "+ peakIndex);

        int minindex=binarySearch(0,peakIndex,mountainArr,target);
        if(minindex!=-1){
            System.out.println(minindex);
        }
        else{
            System.out.println("searching in 2nd block : "+ (peakIndex+1));
            System.out.println(binarySearch2(peakIndex+1,mountainArr.length-1,mountainArr,target));
        }

    }
}
