package BinarySearch;

public class SpecialArrayXElementsGreaterEqualX {
    public static void main(String[] args) {
        int[] nums = {0,4,3,0,4};

        int count;
        for(int i=1;i<1001;i++){
            count=0;
            for(int j=0;j< nums.length;j++){
                if(nums[j]>=i)
                    count+=1;
            }
            if(count==i){
                System.out.println(i);
            }
        }

        int check=0;

    }
}
