package BinarySearch;

public class GuessNumberHigherLower {
    public static void main(String[] args) {
        int target=6;
        int start=0,end=target;

        while(start<=end){
            int mid=start+(end-start)/2;
            if(mid==target){
                System.out.println(mid);
                break;
            }
            if(mid>target){
                end=mid-1;
            }
            else {
                start=mid+1;
            }
        }

    }
}
