package BinarySearch;

public class FindDuplicateNumber {
    public static void main(String[] args) {
        int[] nums = {1,3,4,2,2};
        int max=nums[0];
        for(int i=1;i<nums.length;i++){
            if(nums[i]>max){
                max=nums[i];
            }
        }
        int[] array=new int[max+1];

        for(int i=0;i< nums.length;i++){
            array[nums[i]]++;
            if(array[nums[i]]>=2){

            }
        }

    }
}
