package BinarySearch;

public class ReachNumber {
    public static void main(String[] args) {
        int target=-2;
        int start=0;
        int step=1;
        if(target>=0) {
            while (start <= target) {
                if (start + step == target) {
                    System.out.println(step);
                    break;
                } else {
                    if (start + step > target) {
                        start = start - step;
                    } else {
                        start = step + start;
                    }
                }
                step += 1;
            }
            System.out.println(step);
        }
        else {
            while (true) {
               if(start==target){
                   System.out.println(step);
                   break;
               }
               else{
                   if(start>target){
                       start=start-step;
                   }
               }
                step+=1;
            }
        }
    }
}
