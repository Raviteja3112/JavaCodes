package BinarySearch;

public class IntersectionTwoArrays {
    public static void main(String[] args) {
        int[] nums1 = {4,9,5};
        int[] nums2 = {9,4,9,8,4};
        int[] array=new int[1001];


    }
}
