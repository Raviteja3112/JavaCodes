package BinarySearch;

import java.util.Arrays;

public class TwoDSearch {
    public static int[] search(int[][] nums,int target){
        int r=0,c= nums[0].length-1;

        while(r< nums.length && c>=0){
            if(nums[r][c]==target){
                return new int[]{r,c};
            }
            if(nums[r][c]<target){
                r++;
            }
            else{
                c--;
            }
        }
        return new int[]{-1,-1};
    }
    public static void main(String[] args) {
        int[][] nums={{1,2,3,4},
                {11,21,31,41},
                {12,22,33,44}};

        int[] index=search(nums,12);
        System.out.println(Arrays.toString(index));
    }
}
