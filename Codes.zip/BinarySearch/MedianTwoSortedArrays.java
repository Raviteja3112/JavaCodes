package BinarySearch;

import java.util.Arrays;

public class MedianTwoSortedArrays {
    public static void main(String[] args) {
        int[] nums1 = {1,3};
        int[] nums2 = {2};

       int[] array=new int[nums1.length+ nums2.length];

       int p=0,q=0,index=0;
       while(p< nums1.length && q< nums2.length){
           if(nums1[p]<=nums2[q]){
               array[index]=nums1[p];
               p+=1;
           }
           else{
               array[index]=nums2[q];
               q+=1;
           }
           index+=1;
       }

        System.out.println(p+" "+q);
       if(p<nums1.length){
           while (p< nums1.length){
               array[index]=nums1[p];
               p+=1;
               index+=1;
           }
       }
       else{
           while (q< nums2.length){
               array[index]=nums2[q];
               q+=1;
               index+=1;
           }
       }
        System.out.println(Arrays.toString(array));
       /*
       int k=0;
       for(int i=0;i<nums1.length;i++,k++){
           array[k]=nums1[i];
        }

        for (int i = 0; i < nums2.length ; i++,k++) {
            array[k]=nums2[i];
        }

        Arrays.sort(array);
*/
        if(array.length%2==0){
            int mid= array.length/2;
            System.out.println((double) (array[mid]+array[mid-1])/2);
        }
        else{
            System.out.println((double) array[array.length/2]);
        }

    }
}
