package BinarySearch;

public class InfiniteIndex {
    public static void main(String[] args) {
        int[] array={90,30,4,5,2,7,8,324,68,3,-324,-5,0,0,0,0,0,0,0,0};
        System.out.println(findPosition(array,0,array.length-1));
    }

    private static int findPosition(int[] array, int start, int last) {
        if(start==last){
            if(array[start]==0)
                return start;
            else{
                return -1;
            }
        }
        int mid=(start+last)/2;
        if(array[mid]!=0){
            return findPosition(array,mid+1,last);
        }
        else{
            return findPosition(array,start,mid);
        }
    }
}
