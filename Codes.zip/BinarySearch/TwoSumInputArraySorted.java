package BinarySearch;

public class TwoSumInputArraySorted {

    public static void main(String[] args) {
        int[] numbers = {2,7,11,15};
        int target = 9;

        int start=0,end=numbers.length-1;

        for(int i=0;i< numbers.length;i++){
            if(numbers[start]+numbers[end]==target){
                System.out.println(start+1 +" "+ (end+1));
                break;
            }
            else if(numbers[start]+numbers[end]>target){
                end-=1;
            }
            else{
                start+=1;
            }
        }
    }
}
