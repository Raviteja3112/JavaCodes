package BinarySearch;

public class SearchRotatedSortedArray {
    public static int findHighestPeak(int[] nums){
        int start=0,end=start*2+1;
        if(end>= nums.length){
            end= nums.length-1;
        }
        while(nums[start]<nums[end]){
            start=end;
            end=start*2+1;
            if(end>= nums.length){
                end= nums.length-1;
            }
        }
        for(int i=start;i<end;i++){
            if(nums[i]>nums[i+1]){

                return i;
            }
        }
        return -1;
    }

    public static int binarySearch(int[] nums,int start,int end,int target){
        while(start<=end){
            int mid=start+(end-start)/2;
            if(nums[mid]==target){
                return mid;
            }
            else{
                if(nums[mid]>target){
                    end=mid-1;
                }
                else{
                    start=mid+1;
                }
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        int[] nums = {4,5,6,7,0,1,2};
        int target = 0;

        int highPeak=findHighestPeak(nums);
        int check=binarySearch(nums,0,highPeak,target);
        if(check==-1){

            check=binarySearch(nums,highPeak+1,nums.length-1,target);
        }
        System.out.println(check);
    }
}
