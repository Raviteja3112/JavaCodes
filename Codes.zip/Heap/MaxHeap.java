package Heap;

import static java.lang.Math.*;

public class MaxHeap {
    public static int doing(int n){
        if(n <= 2)
            return 1;
        else
            return doing((int) (floor(sqrt(n)) + n));
    }
    public static void main(String[] args) {
        System.out.println(doing(25));
    }
}
