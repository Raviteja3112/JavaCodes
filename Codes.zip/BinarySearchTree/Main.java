package BinarySearchTree;

class BinaryTree{
    Node root;

    class Node{
        Node left;
        int data;
        Node right;
        Node(int data){
            this.data=data;
        }
    }

    public void insert(int data){
        if(root==null){
            Node temp=new Node(data);
            root=temp;
            root.left=null;
            root.right=null;
            return;
        }
        Node temp=root;
        nextInsert(temp,data);
    }

    private void nextInsert(Node temp,int data){
        if(data<temp.data){
            if(temp.left==null) {
                Node create = new Node(data);
                temp.left = create;
                return;
            }
            nextInsert(temp.left,data);
        }
        else{
            if(temp.right==null) {
                Node create = new Node(data);
                temp.right = create;
                return;
            }
            nextInsert(temp.right,data);
        }
    }

    private void display(Node temp){
        if(temp==null){
            return;
        }
        System.out.print(temp.data+" ");
        display(temp.left);
        display(temp.right);
    }
    public void display(){
       display(root);
    }


}
public class Main {
    public static void main(String[] args) {
        BinaryTree tree=new BinaryTree();
        tree.insert(8);
        tree.insert(5);
        tree.insert(10);
        tree.insert(2);
        tree.insert(4);
        tree.insert(9);
        tree.insert(11);
        tree.display();
    }
}
