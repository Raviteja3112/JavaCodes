package IfElse;

public class SwitchCases {
    public static void main(String[] args) {
        int num=3;

        switch (2){
            default:
                System.out.println("None has selected so i was working");
                break;

            case 1:
                System.out.println("1 has triigered");
                break;

            case 3:
                System.out.println("3 has entered");
                break;


        }

    }
}
