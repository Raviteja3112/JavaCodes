package IfElse;

import java.util.Scanner;

public class Profit {
    public static void main(String[] args){
        int[] nums={3,0,1};

        int[] array=new int[nums.length];

        for (int i = 0; i < nums.length; i++) {
            array[nums[i]]=1;
        }

        for (int i = 0; i < array.length; i++) {
            if(array[i]!=1){

            }
        }

    }
}
