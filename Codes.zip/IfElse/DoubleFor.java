package IfElse;

import java.util.Arrays;

public class DoubleFor {
    public static void main(String[] args) {
        int[] array=new int[1000];
        int[] keys={0,2,2000,998,49,1168,540};
        int[] counters=new int[keys.length];

        for (int i = 0; i < array.length ; i++) {
            array[i]=i*2;
        }

        for (int j = 0; j < keys.length; j++) {
            int start=0,end= array.length-1,isIfStatementExecuted=0,counter=1;
            while (start<=end){
                int mid=(start+end)/2;
                if(array[mid]==keys[j]){
                    isIfStatementExecuted=1;
                    break;
                }
                if(array[mid]>keys[j]){
                    end=mid-1;
                }
                else{
                    start=mid+1;
                }
                counter++;
            }
            if(isIfStatementExecuted==0){
                System.out.println("Not found");
            }
            counters[j]=counter;
        }

        System.out.println("Keys= "+ Arrays.toString(keys));
        System.out.println("Counters= "+Arrays.toString(counters));


    }
}
