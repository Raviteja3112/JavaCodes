package IfElse;

public class HalloSqaure {
    public static void main(String[] args) {

        int num=6;
        for (int row = 1; row <=num; row++) {
            System.out.print("*");
            if(row==1 || row==num){
                for (int col = 1; col <=num ; col++) {
                    System.out.print("*");
                }
            }
            else{

                for (int spaces = 1; spaces <=num-2 ; spaces++) {
                    System.out.print(" ");
                }

            }
            System.out.print("*");
            System.out.println();
        }

    }
}
