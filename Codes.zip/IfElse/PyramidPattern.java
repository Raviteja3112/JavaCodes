package IfElse;

public class PyramidPattern {
    public static void main(String[] args) {

        for (int row = 1; row <=5; row++) {
            for (int spaces = 1; spaces <=5-row ; spaces++) {
                System.out.print(" ");
            }
            int start=row;
            for (int col = 1; col <=row*2-1 ; col++) {
               if(col<row){
                   System.out.print(start++); //4 5 6 7 6 (--)
               }
               else{
                   System.out.print(start--);
               }
            }
            System.out.println();
        }

    }
}
