package IfElse;

import java.util.Scanner;

public class Loops {
    public static void main(String[] args) {
        int input;
        Scanner in=new Scanner(System.in);
        System.out.println("Enter any Multiplaication table: ");
        input= in.nextInt();

        int i;
        for (i=1; i<=10; i++) {
            System.out.println(input+"*"+i+"="+(input*i));
        }

        int whileinput=in.nextInt();
        while(1<=whileinput){
            System.out.println(input+"*"+i+"="+(input*i));
            whileinput++;
        }


    }
}
