package IfElse;

public class Pyramid {
    public static void main(String[] args) {

        int size=10;
        for (int row = 1; row <=size ; row++) {
            for (int spaces = 1; spaces <=size-row; spaces++) {
                System.out.print(" ");
            }

            if(row!=1 && row!=size){
                System.out.print("*");
                for (int spaces = 1; spaces <=(row-1)*2-1 ; spaces++) {
                    System.out.print(" ");
                }
                System.out.println("*");
            }
            else{
                if(row==1){
                    System.out.println("*");
                }
                else{
                    for (int i = 1; i <=size; i++) {
                        System.out.print("* ");
                    }
                }
            }

        }
        
    }
}
