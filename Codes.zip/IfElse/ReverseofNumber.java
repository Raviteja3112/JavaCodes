package IfElse;

import java.util.Scanner;

public class ReverseofNumber {
    public static void main(String[] args) {

        int num=67876;
        int temp=num;
        int store=0;

        while(num>0){
            int remainder=num%10;
            store=store*10+remainder;
            num/=10;
        }

       if(store==temp){
           System.out.println("Its is a palindrome");
       }
       else{
           System.out.println("its not a palindrome");
       }

    }
}
