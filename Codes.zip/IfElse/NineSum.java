package IfElse;

public class NineSum {
    public static void main(String[] args) {
        //2 9+99=108
        //3 9+99+999=1107
        //5 9+99+999+9999+99999
        int num=2;

        int digit=9;
        int store=0;
        for (int i = 1; i <=num; i++) {
            store=store+digit;  //9+99+999
            digit=digit*10+9; //99 999
        }
        System.out.println(store);

    }
}
