package IfElse;

import java.util.*;

public class ArrayBasics {
    public static void main(String[] args) {
        int[] array=new int[1000];
        int[] keys={0,2,2000,998,49,1168,540};
        int[] counters=new int[keys.length];

        for (int i = 0; i < array.length ; i++) {
            array[i]=i*2;
        }

        int isIfStatementExecuted=0;

        for (int j = 0; j < keys.length; j++) {
            int counter=1;
            for (int i = 0; i < array.length; i++,counter++) {
                if(array[i]==keys[j]){
                    isIfStatementExecuted=1;
                    break;
                }
            }
            if(isIfStatementExecuted==0){
                System.out.println("Not found");
            }
            counters[j]=counter;
        }

        System.out.println("Keys= "+Arrays.toString(keys));
        System.out.println("Counters= "+Arrays.toString(counters));

    }
}
