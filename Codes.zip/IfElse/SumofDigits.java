package IfElse;

import java.util.Scanner;

public class SumofDigits {
    public static void main(String[] args) {
        int num;
        Scanner in=new Scanner(System.in);
        System.out.println("Enter any number of digits");
        num=in.nextInt();

        int storing_unit=0;

        while(num>0) {
            int remainder = num % 10;
            storing_unit = storing_unit + remainder;
            num = num / 10;
        }

        System.out.println(storing_unit);

    }
}
