package IfElse;

import java.util.Scanner;

public class Triangle {
    public static void main(String[] args) {
       char num;

        Scanner in=new Scanner(System.in);
        System.out.println("Enter any Character: ");
        num=in.next().charAt(0);
        System.out.println(num);

        if(num>='0' && num<='9'){
            System.out.println("Its a Digit");
        }
       else if((num>='a' && num<='z') || (num>='A' && num<='Z')){
            System.out.println("Its a Alphabet");
        }
       else{
            System.out.println("Special Character");
        }



    }
}
