package Hasing;

class HashCreate{
    int[] hash=new int[10];
    public void insert(int num){
        hash[num%10]=num;
    }
    public void findIndex(int num){
        System.out.println(num%10);
    }
}
public class HashTable {
    public static void main(String[] args) {
        HashCreate hash=new HashCreate();
        hash.insert(625);
        hash.insert(40699);

        hash.findIndex(625);
    }
}
