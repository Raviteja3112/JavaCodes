package Bitwise;

public class BinaryNumberAlternatingBits {
    public static void main(String[] args) {
        int n=5;
        int nextBit=(n&1)^1;
        n=n>>1;
        while(n>0){
            if((n&1)==nextBit){
                nextBit=(n&1)^1;
            }
            else{
                System.out.println(false);
                break;
            }
            n=n>>1;
        }
        System.out.println(true);
    }
}
