package Bitwise;

public class LongestNiceSubstring {
    public static void main(String[] args) {
        String s = "YazaAay";
        String small=s.toLowerCase();
        String name="";
        int start=0;
        for(int i=0;i<s.length()-1;i++){
            if(small.charAt(i)==small.charAt(i+1)){
                start=i;
                continue;
            }
        }

    }
}
