package Bitwise;

public class SortIntegersbyTheNumber1Bits {
    public static int checker(int n){
        int count=0;
        while(n>0){
            if((n&1)==1){
                count+=1;
            }
            n=n>>1;
        }
        return count;
    }
    public static void main(String[] args) {
        int[] arr = {1024,512,256,128,64,32,16,8,4,2,1};

        int max=arr[0];
        for (int i = 1; i < arr.length; i++) {
            max=Math.max(max,arr[i]);
        }
        int bitslength=(int)(Math.log(max)/Math.log(2));
        int[][] matrix=new int[bitslength][arr.length];
        int[] indexChanger=new int[bitslength];


        for(int i=0;i< arr.length;i++){
           int count=checker(arr[i]);
           matrix[count][indexChanger[i]++]=arr[i];
        }

    }
}
