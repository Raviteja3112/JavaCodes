package Bitwise;


public class EvenOdd {
    public static void main(String[] args) {
        int a=241;
        if((a&1)==1){
            System.out.println("odd");
        }
        else{
            System.out.println("even");
        }

    }
}
