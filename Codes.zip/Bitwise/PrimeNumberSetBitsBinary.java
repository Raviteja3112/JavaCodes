package Bitwise;

public class PrimeNumberSetBitsBinary {
    public static int checker(int n){
        int count=0;
        while(n>0){
            if((n&1)==1){
                count+=1;
            }
            n=n>>1;
        }
        return count;
    }

    public static boolean checkPrime(int n){
        for(int i=2;i<Math.sqrt(n);i++){
            if(n%i==0){
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        int left = 10, right = 15,totalCount=0;
        for(int i=left;i<=right;i++){
            int count=checker(i);
            boolean check=checkPrime(count);
            if(check){
                totalCount+=1;
            }
        }
        System.out.println(totalCount);

    }
}
