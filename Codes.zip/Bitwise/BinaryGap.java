package Bitwise;

public class BinaryGap {
    public static int checkDistance(int n){
        int count=0;
        while(n>0){
            count+=1;
            if((n&1)==1){
                return count;
            }
            n=n>>1;
        }
        return count;
    }
    public static void main(String[] args) {
        int n=6;
        int max=Integer.MIN_VALUE;
        while(n>0){
            if((n&1)==0){
                n=n>>1;
                continue;
            }
            n=n>>1;
            int dis=checkDistance(n);
            if(dis>max){
                max=dis;
            }
        }
        System.out.println(max);
    }
}
