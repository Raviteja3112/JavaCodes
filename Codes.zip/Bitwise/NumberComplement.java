package Bitwise;

public class NumberComplement {
    public static void main(String[] args) {
        int num=5;
        int count=0;
        int temp=num;

        while(temp>0){
            count+=1;
            temp=temp>>1;
        }
        temp=(1<<count)-1;
        System.out.println(temp);
    }
}
