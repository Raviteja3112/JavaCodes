package Bitwise;

public class HammingDistance {
    public static int checker(int n){
        int count=0;
        while(n>0){
            if((n&1)==1){
                count+=1;
            }
            n=n>>1;
        }
        return count;
    }

    public static void main(String[] args) {
        int x=3,y=1;
        int result=x^y;
        while((result&1)==0 && result>0){
            result=result>>1;
        }
        if(result>0)
            System.out.println(checker(result));
    }
}
