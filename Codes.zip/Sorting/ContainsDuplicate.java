package Sorting;

import java.util.Arrays;

public class ContainsDuplicate {
    public static void main(String[] args) {
        int[] array = {1,1,1,3,3,4,3,2,4,2};

        Arrays.sort(array);
        for(int i=0;i<array.length-1;i++){
            if(array[i]==array[i+1]){
                break;
            }
        }
        System.out.println(Arrays.toString(array));
    }
}
