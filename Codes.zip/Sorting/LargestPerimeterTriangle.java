package Sorting;

import java.util.Arrays;

public class LargestPerimeterTriangle {
    public static void main(String[] args) {
        int[] nums = {3,6,2,3};
        Arrays.sort(nums);
        int end= nums.length-1;
        while(end-2>=0){
            if(nums[end]+nums[end-1]>nums[end-2] &&
                    nums[end]+nums[end-2]>nums[end-1] &&
                    nums[end-2]+nums[end-1]>nums[end]){
                System.out.println(nums[end-2]+nums[end-1]+nums[end]);
            }
            else{
                end--;
            }
        }
    }
}
