package Sorting;

import java.util.Arrays;

public class SortArrayIncreasingFrequency {

    public static void main(String[] args) {
        int[] nums = {1,5,0,5};

        int[] counter=new int[nums.length];

        for(int i=0;i< nums.length;i++) {
            int count = 1;
            if (nums[i] != Integer.MAX_VALUE) {
                for (int j = i + 1; j < nums.length; j++) {
                    if(nums[j]==nums[i]){
                        count+=1;
                        nums[j]=Integer.MAX_VALUE;
                    }
                }
            }
            counter[i]=count;
        }

        System.out.println(Arrays.toString(nums));
        System.out.println(Arrays.toString(counter));

        int iIncrementor=0;
        int[] array=new int[nums.length];
        for(int i=0;i< counter.length;i++) {
            if (nums[i] != Integer.MAX_VALUE) {
                int min = counter[i];
                int index = i;
                for (int j = 0; j < counter.length; j++) {
                    if (nums[j] != Integer.MAX_VALUE && counter[j] != Integer.MAX_VALUE) {
                        int maxUpto=Math.max(nums[index],nums[j]);
                        if(min >= counter[j]){

                        }

                    }
                }
                for (int k = min; k > 0; k--) {
                    array[iIncrementor++] = nums[index];
                }
                counter[index] = Integer.MAX_VALUE;

            }
        }

        System.out.println(Arrays.toString(array));

    }
}
