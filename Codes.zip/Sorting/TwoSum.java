package Sorting;

import java.util.Arrays;
public class TwoSum {
    public static void main(String[] args) {
        int[] nums = {2,7,11,15};
        int target = 9;
        Arrays.sort(nums);
        int start=0,end= nums.length-1;

        while(start<=end){
            if(nums[start]+nums[end]==target){

            }
            else{
                if(nums[start]+nums[end]>target){
                    end--;
                }
                else{
                    start++;
                }
            }
        }
    }
}
