package Sorting;

import java.util.Arrays;

public class RankTransformArray {
    public static void main(String[] args) {
        int[] nums = {40,10,20,30};
        int[] sorted=nums.clone();
        int[] rank=new int[sorted.length];
        Arrays.sort(sorted);

        System.out.println("Sorted array: "+ Arrays.toString(sorted));

        for (int i = 0; i < nums.length; i++) {
            int target=nums[i];
            int start=0,end= nums.length-1;
            while(start<=end){
                int mid=start+(end-start)/2;
                if(sorted[mid]==target){
                    int check=mid;
                    while(check>0 && sorted[check]==sorted[check-1]){
                        check-=1;
                    }
                    rank[i]=check+1;
                    break;
                }
                else{
                    if(sorted[mid]>target){
                        end=mid-1;
                    }
                    else{
                        start=mid+1;
                    }
                }
            }
        }
        System.out.println(Arrays.toString(rank));
    }
}
