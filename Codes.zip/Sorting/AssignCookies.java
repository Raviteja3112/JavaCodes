package Sorting;

import java.util.Arrays;

public class AssignCookies {
    public static void main(String[] args) {
        int[] g={7,8,9,10},s={5,6,7,8};

        Arrays.sort(g);
        Arrays.sort(s);
        int count=0;
        int i=0;
        int startg=0,starts=0;

        while(startg<g.length && starts<s.length){
            if(s[starts]>=g[startg]){
                count+=1;
                startg+=1;
                starts+=1;
            }
            else{
                starts+=1;
            }
        }
        System.out.println(count);
    }
}
