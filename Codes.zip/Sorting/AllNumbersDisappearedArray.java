package Sorting;

import java.util.ArrayList;

public class AllNumbersDisappearedArray {
    public static void main(String[] args) {
        int[] nums = {4,3,2,7,8,2,3,1};
        int[] array=new int[nums.length];

        for(int i=0;i< nums.length;i++){
            array[nums[i]-1]+=1;
        }
        ArrayList<Integer> list=new ArrayList<>();
        for(int i=0;i< nums.length;i++){
            if(array[i]==0){
                list.add(i+1);
            }
        }
        System.out.println(list);
    }
}
