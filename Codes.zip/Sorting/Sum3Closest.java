package Sorting;

import java.util.Arrays;

public class Sum3Closest {
    public static void main(String[] args) {
        int[] nums = {0,2,1,-3};
        int target = 1;

        Arrays.sort(nums);
        System.out.println(Arrays.toString(nums));


        int closest=Integer.MAX_VALUE;
        int prevclose=nums[0]+nums[1]+nums[2];
        for(int i=1;i< nums.length-2;i++){
            int currentclose=nums[i]+nums[i+1]+nums[i+2];
            if(target>=0)
                closest=prevclose-target>=currentclose-target?prevclose:currentclose;
            else
                closest=target-prevclose>=target-currentclose?prevclose:currentclose;
            prevclose=currentclose;
        }
        System.out.println(closest);
    }
}
