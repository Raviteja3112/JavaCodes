package Sorting;

public class MissingNumber {
    public static void main(String[] args) {
        int[] array={3,4,6,7,0,9,8,1,2};

        int i=0;
        while(i< array.length){
            int correctIndex=array[i];
            if(array[i]< array.length && array[i]!=i){
                int temp=array[i];
                array[i]=array[correctIndex];
                array[correctIndex]=temp;
            }
            else{
                i++;
            }
        }

        for(i=0;i< array.length;i++){
            if(array[i]!=i){

            }
        }
    }
}
