package Sorting;

import java.awt.*;
import java.util.Arrays;

public class MaximumGap {
    public static int maximumGap(int[] nums) {
        if(nums.length<2)
            return 0;
        int max=nums[0];

        String name="Raviteja";
        char[] chars=name.toCharArray();
        Arrays.sort(chars);

        int diff=Integer.MIN_VALUE;
        for(int i=nums.length-1;i>0;i--){
            int sub=nums[i]-nums[i-1];
            if(diff<sub){
                diff=sub;
            }
        }
        return diff;
    }
    public static void main(String[] args) {
        int[] nums = {3,6,9,1};
        System.out.println(maximumGap(nums));
    }
}
