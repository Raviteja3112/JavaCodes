package Sorting;

import java.util.*;
public class ValidAnagram {
    public static char isAnagram(String s, String t) {
        /*if(s.length()!=t.length())
            return false;
        int[] as=new int[26];
        int[] at=new int[26];

        for (int i = 0; i < s.length(); i++) {
            int index=(int)s.charAt(i)-97;
            as[index]+=1;
        }
        for (int i = 0; i < t.length(); i++) {
            int index=(int)t.charAt(i)-97;
            at[index]+=1;
        }

        for(int i=0;i<s.length();i++){
            if(as[i]!=at[i]){
                return false;
            }
        }
        return true;

         */
        int[] as=new int[26];
        int[] at=new int[26];

        for (int i = 0; i < s.length(); i++) {
            int index=(int)s.charAt(i)-97;
            as[index]+=1;
        }
        for (int i = 0; i < t.length(); i++) {
            int index=(int)t.charAt(i)-97;
            at[index]+=1;
        }

        for(int i=0;i<s.length();i++){
            if(as[i]!=at[i]){
                return (char)(i+97);
            }
        }
        return (char)31;
    }
    public static void main(String[] args) {
        String s = "abcd", t = "abcde";
        System.out.println(isAnagram(s,t));
    }
}
