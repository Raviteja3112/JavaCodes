package Sorting;

import java.util.Arrays;

public class KthLargestElementArray {
    public static void main(String[] args) {
        int[] nums={3,2,3,1,2,4,5,5,6};
        int k=4;
        int count=0;
        int max=nums[0];
        int largest=Integer.MIN_VALUE;
        for(int i=1;i< nums.length;i++){
            if(max<=nums[i]){
                count++;
            }
            if(i== nums.length-1){
                int x=count;
            }
        }
        System.out.println(largest);
    }
}
