package Sorting;

import java.util.Arrays;

public class MergeSortedArray {
    public static void main(String[] args) {
        int[] nums1 = {1,2,3,0,0,0};
        int m = 3;
        int[] nums2 = {2,5,6};
        int n = 3;

        int p=0,q=0,k=0;

        int[] array=new int[m+n];
        while(p<m && q<n){
            if(nums1[p]<=nums2[q]){
                array[k]=nums1[p];
                p++;
            }
            else{
                array[k]=nums2[q];
                q++;
            }
            k++;
        }

        if(p==m){
            for(int i=q;i<n;i++,++k){
                array[k]=nums2[i];
            }
        }
        else {
            for(int i=p;i<m;i++,++k){
                array[k]=nums1[i];
            }
        }
        for(int i=0;i< nums1.length;i++,++k){
            nums1[i]=array[i];
        }
        System.out.println(Arrays.toString(nums1));
    }
}
