package Sorting;

import java.util.ArrayList;

public class Arrays {
    public static void main(String[] args) {
        ArrayList<Integer> list=new ArrayList<>();

        list.add(31);
        list.add(24);

        System.out.println(list.size());
        list.remove(0);
        System.out.println(list);
        System.out.println(list.size());
    }
}
