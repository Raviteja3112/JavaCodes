package Sorting;

import java.util.Arrays;

public class SquaresSortedArray {
    public static void swap(int[] nums,int start,int end){
        int temp=nums[start];
        nums[start]=nums[end];
        nums[end]=temp;
    }

    public static void main(String[] args) {
        int[] nums = {-4,-1,0,3,10};

        for(int i=0;i<nums.length;i++){
            nums[i]=nums[i]*nums[i];
        }
        System.out.println(Arrays.toString(nums));
        int start=0,end=nums.length-1;
        while(start<end) {
            if (nums[start] > nums[end]) {
                int temp = nums[start];
                nums[start] = nums[end];
                nums[end] = temp;
                end--;
            }
            if (nums[start] < nums[end]) {
                start++;
            }
        }
        System.out.println(Arrays.toString(nums));
    }
}
