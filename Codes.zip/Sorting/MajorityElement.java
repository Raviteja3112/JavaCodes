package Sorting;



public class MajorityElement {
    public static void main(String[] args) {
        int[] array = {2,2,1,1,1,2,2};

        int major=array[0];
        int count=1;
        for(int i=1;i<array.length;i++){
            if(array[i]==major)
                count++;
            else{
                count--;
            }
            if(count==0){
                major=array[i];
                count=1;
            }
        }
        System.out.print(major);
    }
}
