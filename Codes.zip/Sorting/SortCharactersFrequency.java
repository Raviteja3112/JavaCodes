package Sorting;

import java.util.Arrays;

public class SortCharactersFrequency {
    public static void main(String[] args) {
        int[] score={10,3,8,9,4};

        String[] result=new String[score.length];
        int max=Integer.MIN_VALUE;
        int index=0;
        for (int i = 0; i < score.length; i++) {
            for (int j = 0; j < score.length; j++) {
                if(score[j]>max){
                    max=score[j];
                    index=j;
                }
            }
            if(i==0){
                result[index]="Gold Medal";
            }
            if(i==1){
                result[index]="Silver Medal";
            }
            if(i==2){
                result[index]="Bronze Medal";
            }
            if(i>2){
                result[index]=Integer.toString(max);
            }
            score[index]=-1;
            max=-1;
        }

        System.out.println(Arrays.toString(result));
    }
}
