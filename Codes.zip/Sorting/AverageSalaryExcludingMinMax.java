package Sorting;

public class AverageSalaryExcludingMinMax {
    public static void main(String[] args) {
        int[] salary = {1000,2000,3000};

        int max=Integer.MIN_VALUE;
        int min=Integer.MAX_VALUE;

        for(int i=0;i< salary.length;i++){
            if(max<salary[i]){
                max=salary[i];
            }

                if(min>salary[i]){
                    min=salary[i];
                }

        }

        System.out.println(max+" "+min);
        int sum=0;
        for (int i = 0; i < salary.length; i++) {
            if(salary[i]!=min && salary[i]!=max){
                sum+=salary[i];
            }
        }
        System.out.println((double) sum/2);
    }
}
