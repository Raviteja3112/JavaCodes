package Sorting;

import java.awt.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MinimumAbsoluteDifference {
    public static int minAbsDiff(int[] nums){
        int min=Integer.MAX_VALUE;
        Arrays.sort(nums);
        for(int i=0;i< nums.length-1;i++){
            min=Math.min(Math.abs(nums[i]-nums[i+1]),min);
        }
        return min;
    }
    public static void main(String[] args) {
        int[] arr = {3,8,-10,23,19,-4,-14,27};
        int min=minAbsDiff(arr);
        System.out.println(min);
        List<List<Integer>> list=new ArrayList<>();

        for(int i=0;i< arr.length-1;i++){
            if(Math.abs(arr[i]-arr[i+1])==min){
                List<Integer> pairs=new ArrayList<>();
                pairs.add(arr[i]);
                pairs.add(arr[i+1]);
                list.add(pairs);
            }
        }
        System.out.println(list);
    }
}
