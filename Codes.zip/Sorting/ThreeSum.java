package Sorting;

import java.util.ArrayList;
import java.util.Arrays;

public class ThreeSum {
    public static void main(String[] args) {
        int[] nums = {-1,0,1,2,-1,-4};
        ArrayList<ArrayList<Integer>> matrix=new ArrayList<ArrayList<Integer>>();
        Arrays.sort(nums);


        ArrayList<Integer> list=new ArrayList<>(nums.length);

        for(int i=0;i< nums.length;i++){
            list.add(nums[i]);
        }

        int k=0,i=0;

        while(i< list.size())
        {
            boolean isWorked=false;
            int start=i+1,end= list.size()-1;
            System.out.println("start: "+start+"  end:"+end);
            while(start<end){
                if(nums[i]+nums[start]+nums[end]==0){
                    matrix.add(new ArrayList<>());
                    matrix.get(k).add(nums[i]);
                    matrix.get(k).add(nums[start]);
                    matrix.get(k).add(nums[end]);
                    System.out.println(matrix.get(k));
                    list.remove(i);
                    list.remove(start-1);
                    list.remove(end-2);
                    System.out.println("After removed: "+ list);
                    k++;
                    isWorked=true;
                    break;
                }
                else{
                    if(nums[i]+nums[start]+nums[end]>0){
                        end--;
                    }
                    else{
                        start++;
                    }
                }
            }
            if(!isWorked){
                i++;
            }
            else{
                i=0;
            }

        }

        for(i=0;i< matrix.size();i++){
            System.out.println(matrix.get(i));
        }

    }
}
