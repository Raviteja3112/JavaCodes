package Sorting;
import java.util.Arrays;
public class ThirdMaximumNumber {
    public static void main(String[] args) {
        int[] nums={3,2,4,1};

        int index = 0,last= nums.length-1,passes=1;
        for(int i= 0;i< nums.length;i++){
            int max=nums[0];
            for(int j=0;j< nums.length-i;j++){
                if(max<=nums[j]){
                    max=nums[j];
                    index=j;
                }
            }
            max=nums[index];
            nums[index]=nums[last];
            nums[last]=max;
            if(last!= nums.length-1 && nums[last]!=nums[last+1]){
                passes+=1;
            }
            if(passes==3){
                System.out.println(nums[last]);
                break;
            }
            last-=1;
        }

    }
}
