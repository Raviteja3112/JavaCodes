package Sorting;

import java.util.Arrays;

public class HeightChecker {
    public static void main(String[] args) {
        int[] array = {1,1,4,2,1,3};

        int[] heights=new int[array.length];

        for(int i=0;i<array.length;i++){
            heights[i]=array[i];
        }


        System.out.println(Arrays.toString(heights));
    }
}
