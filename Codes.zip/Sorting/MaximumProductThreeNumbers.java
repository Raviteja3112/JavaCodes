package Sorting;

import java.util.Arrays;

public class MaximumProductThreeNumbers {
    public static void main(String[] args) {

        int[] nums={-100,-98,-1,2,3,4};
        Arrays.sort(nums) ;

        int max=nums[0]*nums[1]*nums[nums.length-1];
        int last=nums.length-1;
        int max2=nums[last]*nums[last-1]*nums[last-2];
        System.out.println(Math.max(max,max2));
    }
}
