package Sorting;

import java.util.*;

public class IntersectionTwoArrays {
    public static void main(String[] args) {
        int[] nums1 = {4, 9, 5};
        int[] nums2 = {9, 4, 9, 8, 4};

        Set<Integer> list1 = new HashSet<>();
        for (int i = 0; i < nums1.length; i++) {
            list1.add(nums1[i]);
        }

        Set<Integer> list2 = new HashSet<>();
        for (int i = 0; i < nums2.length; i++) {
            list2.add(nums2[i]);
        }

        list1.retainAll(list2);

        int[] array=new int[list1.size()];
        int i=0;
        for(int num:list1){
            array[i]=num;
            i++;
        }

    }
}
