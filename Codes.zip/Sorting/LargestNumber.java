package Sorting;

import java.util.Arrays;

public class LargestNumber {
    public static void main(String[] args) {
        int[]  nums = {3,30,34,5,9};
        Arrays.sort(nums);

        String largenumber;
    }
}
