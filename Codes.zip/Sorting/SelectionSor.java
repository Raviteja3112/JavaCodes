package Sorting;

import java.util.Arrays;

public class SelectionSor {
    public static void main(String[] args) {
        int[] array={3,1,2};

        for(int i=0;i< array.length;i++){
            int min=array[i];
            int minIndex=i;
            for(int j=i;j< array.length;j++){
                if(min>array[j]){
                    min=array[j];
                    minIndex=j;
                }
            }
            min=array[i];
            array[i]=array[minIndex];
            array[minIndex]=min;

        }
        System.out.println(Arrays.toString(array));
    }
}
