package Sorting;

import java.util.Arrays;

public class BubbleSort {
    public static void main(String[] args) {
        int[] array={3,1,2,5,4,0,8};

        for(int i=0;i< array.length;i++){
            boolean isSwapped=false;
            for(int j=0;j< array.length-i-1;j++){
                if(array[j]>array[j+1]){
                    int temp=array[j];
                    array[j]=array[j+1];
                    array[j+1]=temp;
                    isSwapped=true;
                }
            }
            if(!isSwapped){
                // if not swapped then break the loop
                break;
            }
        }

        System.out.println(Arrays.toString(array));
    }
}
