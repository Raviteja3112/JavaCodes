package Sorting;

import java.util.Arrays;

public class MergeSort {
    public static int[] merge(int[] nums1,int[] nums2){
        int i=0,j=0,indexInc=0;
        int[] newMergedList=new int[nums1.length+ nums2.length];
        while(i< nums1.length && j< nums2.length){
            if(nums1[i]<nums2[j]){
                newMergedList[indexInc]=nums1[i];
                i++;
            }
            else{
                newMergedList[indexInc]=nums2[j];
                j++;
            }
            indexInc++;
        }

        while(i< nums1.length){
            newMergedList[indexInc++]=nums1[i];
            i++;
        }
        while(j< nums2.length){
            newMergedList[indexInc++]=nums2[j];
            j++;
        }
        return newMergedList;
    }


    public static int[] mergesort(int[] nums){
        if(nums.length==1){
            return nums;
        }
        int mid= nums.length/2;
        int[] left=mergesort(Arrays.copyOfRange(nums,0,mid));
        int[] right=mergesort(Arrays.copyOfRange(nums,mid,nums.length));
        return merge(left,right);
    }

    public static void main(String[] args) {
        int[] nums={5,4,3,1,2,10,7,19,12,15,44,30};
        nums=mergesort(nums);
        System.out.println(Arrays.toString(nums));
    }
}
