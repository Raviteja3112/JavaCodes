package LinkedLists;

class Node {
    private String carrier;
    private String infected;
    private Node next;
    public Node(String carrier, String infected, Node next) {
        this.carrier = carrier;
        this.infected = infected;
        this.next = next;
    }
    public String getCarrier() {
        return carrier;
    }
    public String getInfected() {
        return infected;
    }
    public Node getNext() {
        return next;
    }
    public void setCarrier(String c) {
        carrier = c;
    }
    public void setInfected(String i) {
        infected = i;
    }
    public void setNext(Node n) {
        next = n;
    }

    public String toString() {
        return "[" + carrier + "," + infected + "]--> ";
    }
}

class LinkedList{
    private Node head;
    private int count;

    public LinkedList(){
        head=null;
        count=0;
    }

    public int size(){return count;}
    public Node getFirst(){return head;}

    public void inputString(String data){

        String[] virusdata=data.split(" ");
        int len= virusdata.length-2;
        int index=0;
        while(index!=len) {
            if (head == null) {
                Node node = new Node(virusdata[0], virusdata[1], null);
                head = node;
                count += 1;
            }
            else {
                Node temp = head;
                while (temp.getNext() != null) {
                    temp = temp.getNext();
                }
                Node node = new Node(virusdata[index], virusdata[index+1], null);
                temp.setNext(node);
                count+=1;
            }
            index+=2;
        }
    }

    public void printLinkedList(){
        Node temp=head;
        while(temp!=null){
            System.out.print(temp.toString());
            temp=temp.getNext();
        }
        System.out.println();
    }

    public String printCarriers(){
        System.out.print("Carriers: ");
        Node temp=head;
        String carriers="";
        while(temp!=null){
            if(!carriers.contains(temp.getCarrier())){
                carriers+=temp.getCarrier()+" ";
            }
            temp=temp.getNext();
        }
        return carriers;
    }

    public String printInfected(){
        System.out.print("Infected: ");
        Node temp=head;
        String infected="";
        while(temp!=null){
            if(!infected.contains(temp.getInfected())){
                infected+=temp.getInfected()+" ";
            }
            temp=temp.getNext();
        }
        return infected;
    }

    public String printImmune(String carrierlist,String immunelist){
        System.out.print("Immune: ");
        String[] infectd=immunelist.split(" ");
        String immune="";
        for (int i = 0; i < infectd.length; i++) {
            if(!carrierlist.contains(infectd[i])){
                immune+=infectd[i]+" ";
            }
        }
        return immune;
    }

}


public class VirusDemo {
    public static void main(String[] args) {
        LinkedList viruslist=new LinkedList();
        String virusPeople="Stan Alice Ken Jen Alice Tara Jane Sue Sue Que Jen Que * Que";
        //String virusPeople="* Bob";

        viruslist.inputString(virusPeople);

        System.out.println("Number of Pairs: "+viruslist.size());
        viruslist.printLinkedList();

        String carrierlsit=viruslist.printCarriers();
        System.out.println(carrierlsit);

        String infectedlist=viruslist.printInfected();
        System.out.println(infectedlist);

        String immunelist=viruslist.printImmune(carrierlsit,infectedlist);
        System.out.println(immunelist);

        String[] name=virusPeople.split(" ");
        System.out.println(name[name.length-1]+ " Spreads to: ");

    }
}
