package LinkedLists.SingleLL;

class Remo extends LL{
    public void remove(){
        Node temp=head;
        while(temp.next!=null){
            if(temp.value==temp.next.value){
                temp.next=temp.next.next;
            }
            else{
                temp=temp.next;
            }
        }
    }
}
public class RemoveDup {
    public static void main(String[] args) {
        Remo list=new Remo();
        list.insertLast(1);
        list.insertLast(1);
        list.insertLast(2);
        list.insertLast(3);
        list.insertLast(3);
        list.remove();
    }
}
