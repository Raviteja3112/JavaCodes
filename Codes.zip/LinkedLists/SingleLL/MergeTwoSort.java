package LinkedLists.SingleLL;

public class MergeTwoSort extends LL{
    public LL merge(LL list1,LL list2){
        Node temp1=list1.head;
        Node temp2=list2.head;

        LL list=new LL();
        while(temp1!=null && temp2!=null){
            if(temp1.value<= temp2.value){
                list.insertLast(temp1.value);
                temp1=temp1.next;
            }
            else{
                list.insertLast(temp2.value);
                temp2=temp2.next;
            }
        }
        if(temp1!=null){
            while(temp1!=null){
                list.insertLast(temp1.value);
                temp1=temp1.next;
            }
        }
        else{
            while(temp2!=null){
                list.insertLast(temp2.value);
                temp2=temp2.next;
            }
        }

        return list;
    }
}
