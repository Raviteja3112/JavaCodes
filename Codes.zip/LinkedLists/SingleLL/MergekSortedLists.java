package LinkedLists.SingleLL;

import java.util.List;

public class MergekSortedLists {
    public static void main(String[] args) {
        int[][] lists = {{1,4,5},{1,3,4},{2,6}};

    }
}
