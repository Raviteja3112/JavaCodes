package LinkedLists.SingleLL;

public class Main {
    public static void main(String[] args) {
        MergeTwoSort list1=new MergeTwoSort();
        MergeTwoSort list2=new MergeTwoSort();
        list1.insertLast(1);
        list1.insertLast(2);
        list1.insertLast(4);
        list2.insertLast(1);
        list2.insertLast(3);
        list2.insertLast(4);

        LL list=new MergeTwoSort().merge(list1,list2);
        list.display();
    }
}
