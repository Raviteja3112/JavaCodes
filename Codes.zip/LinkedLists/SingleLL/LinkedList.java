package LinkedLists.SingleLL;

import java.util.Stack;

class LL {
    public Node head;
    protected Node tail;
    protected int size=0;
    static class Node{
        protected int value;
        protected Node next;
        Node(int value){
            this.value=value;
            next=null;
        }
    }

    public void insert(int value,int index){
        if(head==null && tail==null){
            insertStart(value);
            return;
        }
        if(size==index){
            insertLast(value);
            return;
        }

        Node temp=head;
        for(int i=0;i<index-1;i++){
            temp=temp.next;
        }
        Node node=new Node(value);
        node.next=temp.next;
        temp.next=node;
        sizeInc();
    }


    public void insertLast(int data){
        Node node=new Node(data);
        if(head==null && tail==null){
            head=node;
            tail=node;
        }
        else{
            tail.next=node;
            tail=node;
        }
        sizeInc();
    }

    public void insertStart(int data){
        Node node=new Node(data);
        node.next=head;
        head=node;
        sizeInc();
    }

    public void displayRev(Node temp){
        if(temp==null){
            return;
        }
        displayRev(temp.next);
        System.out.print(temp.value+"->");
    }
    public void displayRev(){
        displayRev(head);
    }

    public void display(){
        Node temp=head;
        while(temp!=null){
            System.out.print(temp.value+ "->"+" ");
            temp=temp.next;
        }
        System.out.print("End");
        System.out.println();
    }
    public void display(Node head){
        Node temp=head;
        while(temp!=null){
            System.out.print(temp.value+ "->"+" ");
            temp=temp.next;
        }
        System.out.print("End");
        System.out.println();
    }

    public void listSize(){
        System.out.println(size);
    }



    private void sizeInc(){
        size+=1;
    }
    private void sizeDec(){
        size-=1;
    }

    public int deleteFirst(){
        int val= head.value;
        head=head.next;
        sizeDec();
        return val;
    }

    public int deleteLast(){
        Node temp=head;
        for(int i=1;i<size-1;i++){
            temp=temp.next;
        }
        int val= temp.next.value;
        temp.next=null;
        sizeDec();
        return val;
    }

    public int delete(int index){
        Node prev=head;
        Node temp=head.next;

        for(int i=0;i<index-1;i++){
            prev=prev.next;
            temp=temp.next;
        }
        int val= temp.value;
        prev.next=temp.next;
        sizeDec();
        return val;
    }

    public Node reverseList(Node head){
        Node ptr=head;
        head=head.next;
        ptr.next=null;

        while(head!=null){
            Node firstnode=head;
            head=head.next;
            firstnode.next=ptr;
            ptr=firstnode;

        }
        head=ptr;
        return head;
    }



    public Node middle(Node head){
        Node temp=head,ptr=head;

        while(ptr.next!=null && ptr.next.next!=null){
            ptr=ptr.next.next;
            temp=temp.next;
        }
        return temp;

    }
    public void reorderList() {
        Node mid=middle(head);
        System.out.println(mid.value);
        Stack<Node> stack=new Stack<>();
        mid=mid.next;
        while(mid!=null){
            System.out.println(mid+" "+mid.value);
            stack.push(mid);
            mid=mid.next;
        }

        Node temp=head;

        while(!stack.isEmpty()){
            Node pop=stack.pop();
            System.out.println(pop.value);
            pop.next=temp.next;
            temp.next=pop;
            temp=temp.next.next;

        }
        temp.next=null;

    }
}


public class LinkedList {
    public static void main(String[] args) {
        LL list=new LL();
        list.insertLast(1);
        list.insertLast(2);
        list.insertLast(3);
        list.insertLast(4);
        list.insertLast(5);


        list.display();
        list.reorderList();
        list.display();
    }
}

