package LinkedLists.Circular;

class Circular{
    Node head;
    Node tail;
    private class Node{
        int data;
        Node next;
        Node(int data){
            this.data=data;
        }
    }

    public void insert(int data){
        Node node =new Node(data);
        if(head==null){
            head=node;
            head.next=head;
            tail=node;
            tail.next=tail;
            return;
        }
        tail.next=node;
        node.next=head;
        tail=node;
    }

    public void delete(int data) {
        if (head.data == data) {
            head = head.next;
            return;
        }
        Node prev = head;
        Node temp = head.next;
        while (temp.data != data && head != temp) {
            prev = temp;
            temp = temp.next;
        }
        if (head != temp) {
            prev.next = temp.next;
            return;
        }
        System.out.println("Enter number not there");
    }

    public void display(){
        Node temp=head;
        do {
            System.out.print(temp.data+"-->");
            temp=temp.next;
        }while (temp!=head);

        System.out.print("END");
        System.out.println();
    }
}
public class CircularLL {
    public static void main(String[] args) {
        Circular list=new Circular();
        list.insert(31);
        list.insert(24);
        list.insert(69);
        list.insert(55);
        list.display();
        list.delete(69);
        list.display();
    }
}
