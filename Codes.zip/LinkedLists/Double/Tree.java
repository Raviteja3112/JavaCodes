package LinkedLists.Double;

class BinaryTree{
    Node root;

    class Node{
        int data;
        Node left;
        Node right;
        Node(int data){
            this.data=data;
        }
    }
    BinaryTree(int data){
        Node temp=new Node(data);
    }

    public void create(){
        Node a=new Node(1);
        Node b=new Node(2);
        Node c=new Node(3);
        Node d=new Node(4);
        Node obj5=new Node(5);
        Node obj6=new Node(6);
        Node obj7=new Node(7);
    }
}
public class Tree {

}
