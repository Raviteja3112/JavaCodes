package LinkedLists.Double;

class DLL{
    private Node head;
    private Node tail;

    private class Node{
        private int data;
        private Node next;
        private Node prev;
        Node(int data){
            this.data=data;
        }
    }

    public void insertLast(int data){
        if(head==null && tail==null){
            Node node=new Node(data);
            head=node;
            tail=node;
            head.prev=null;
            head.next=null;
            return;
        }
        Node node=new Node(data);
        tail.next=node;
        node.prev=tail;
        tail=node;

    }
    public void insertFirst(int data){
        Node node=new Node(data);
        node.next=head;
        head.prev=node;
        node.prev=null;
        head=node;
    }
    public void display(){
        Node temp=head;
        while(temp!=null){
            System.out.print(temp.data+ "<=>"+" ");
            temp=temp.next;
        }
        System.out.print("End");
    }
}
public class DoublyLinkedList {
    public static void main(String[] args) {
        DLL list=new DLL();
        list.insertLast(31);
        list.insertLast(24);
        list.insertFirst(55);
        list.display();
    }
}
